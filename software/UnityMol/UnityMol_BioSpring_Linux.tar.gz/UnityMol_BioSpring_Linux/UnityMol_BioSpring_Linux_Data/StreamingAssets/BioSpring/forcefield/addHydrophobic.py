import pandas
import sys

ffFilename = sys.argv[1]

residueName1To3 = {
        "A": "ALA",
        "R": "ARG",
        "N": "ASN",
        "D": "ASP",
        "B": "ASX",
        "C": "CYS",
        "E": "GLU",
        "Q": "GLN",
        "Z": "GLX",
        "G": "GLY",
        "H": "HIS",
        "I": "ILE",
        "L": "LEU",
        "K": "LYS",
        "M": "MET",
        "F": "PHE",
        "P": "PRO",
        "S": "SER",
        "T": "THR",
        "W": "TRP",
        "Y": "TYR",
        "V": "VAL"}

kdHydroDic = {
        "ALA": 1.8,
        "ARG": -4.5,
        "ASN": -3.5,
        "ASP": -3.5,
        "ASX": -3.5,
        "CYS": 2.5,
        "GLU": -3.5,
        "GLN": -3.5,
        "GLX": -3.5,
        "GLY": -0.4,
        "HIS": -3.2,
        "ILE": 4.5,
        "LEU": 3.8,
        "LYS": -3.9,
        "MET": 1.9,
        "PHE": 2.8,
        "PRO": -1.6,
        "SER": -0.8,
        "THR": -0.7,
        "TRP": -0.9,
        "TYR": -1.3,
        "VAL": 4.2}



with open(ffFilename, newline='') as ffFile:
    data = pandas.read_csv(ffFile, delimiter='\t', header=0)
    
    for i, row in enumerate(data.values):
        resCode1 = row[0][0]
        resCode3 = residueName1To3[resCode1]
        data.loc[i, ("Hydrophobicity")] = kdHydroDic[resCode3]

    #print(data.style.set_properties(**{'text-align': 'left'}).to_excel())
    
    #print (.to_string(index=False))

    data.to_csv(sys.argv[2], sep='\t', index=False)
