#ifndef _FORCEFIELDELECTROSTATICCOULOMBANDSTERICLENNARDJONES_8_6_AMBER_H_
#define _FORCEFIELDELECTROSTATICCOULOMBANDSTERICLENNARDJONES_8_6_AMBER_H_

#include "ForceField.h" 

class ForceFieldElectrostaticCoulombAndStericLennardJones_8_6Amber: public ForceField
	{
	public : 
		

		ForceFieldElectrostaticCoulombAndStericLennardJones_8_6Amber();
		virtual ~ForceFieldElectrostaticCoulombAndStericLennardJones_8_6Amber();
		virtual double computeStericForceModule(double radius1, double radius2, double epsilon1, double epsilon2,double distance) ; 

		virtual double computeStericEnergy(double radius1, double radius2, double epsilon1, double epsilon2,double distance) ; 


	
		

	};

#endif
