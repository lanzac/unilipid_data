
#ifndef __GRIDBASE_H__
#define __GRIDBASE_H__

#include <array>
#include <utility>

#include "Cell.h"
#include "GridCoordinatesTransform.h"
#include "utils.h"

template <typename T> class __GridBase
{
  public:
    // Constructs from size, spacing and origin.
    __GridBase(size_t sizei, size_t sizej, size_t sizek, double deltax, double deltay, double deltaz, double offsetx,
               double offsety, double offsetz)
        : _data(), _T(sizei, sizej, sizek, deltax, deltay, deltaz, offsetx, offsety, offsetz)
    {
        __resize();
    }

    // Empty constructor.
    __GridBase() : __GridBase(0, 0, 0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0) {}

    // Constructs from box and spacing.
    __GridBase(std::array<double, 6> box, std::array<double, 3> spacing) : _T(box, spacing) { __resize(); }

    // Constructs from box center and length and grid spacing.
    __GridBase(double centerx, double centery, double centerz, double delta, double distance)
        : _data(), _T(centerx, centery, centerz, delta, distance)
    {
        __resize();
    }

    virtual ~__GridBase() {}

    //
    // Grid size manipulations
    //

    // Returns the Grid size in terms of memory allocated (which btw shouldn't be
    // different from the dimensions).
    size_t size() { return _data.size(); }

    // Resizes the grid and reserves the adequate amount of memory.
    void resize(const std::array<size_t, 3> shape)
    {
        _T.shape = shape;
        __resize();
    }

    void resize(const size_t sizei, const size_t sizej, const size_t sizek) { resize({sizei, sizej, sizek}); }

    // Aliases for resize.
    void reshape(const std::array<size_t, 3> shape) { resize(shape); }
    void reshape(const size_t sizei, const size_t sizej, const size_t sizek) { resize({sizei, sizej, sizek}); }

    //
    // Getters/setters
    //

    // Get/Sets origin.
    void setOrigin(const std::array<double, 3> & a) { _T.origin = a; }
    const std::array<double, 3> & getOrigin() const { return _T.origin; }

    // Get/Sets spacing.
    void setSpacing(const std::array<double, 3> & a) { _T.spacing = a; }
    const std::array<double, 3> & getSpacing() const { return _T.spacing; }

    // Get shape, in various fashions.
    const std::array<size_t, 3> & getShape() const { return _T.shape; }
    const std::array<size_t, 3> & getSize() const { return getShape(); }

    // Returns true is discrete coordiantes are within the grid boundaries.
    bool isValidCoordinates(const int i, const int j, const int k)
    {
        return _T.isValidDiscreteCoordinates(i, j, k);
    }

    //
    // Access to grid items
    //

    // Access to elements by discrete coordinates.
    // Throws std::out_of_range if coordinates are outside the grid.
    typename std::vector<T>::reference at(size_t i, size_t j, size_t k)
    {
        size_t index = 0;
        if (not _T.discreteToIndex(i, j, k, index))
        {
            std::string s = String::format("Grid: invalid index %dx%dx%d (Grid is %dx%dx%d)", i, j, k, _T.shape[0],
                                           _T.shape[1], _T.shape[2]);
            throw std::out_of_range(s);
        }
        return _data[index];
    }

    typename std::vector<T>::const_reference at(size_t i, size_t j, size_t k) const
    {
        size_t index = 0;
        if (not _T.discreteToIndex(i, j, k, index))
        {
            std::string s = String::format("Grid: invalid index %dx%dx%d (Grid is %dx%dx%d)", i, j, k, _T.shape[0],
                                           _T.shape[1], _T.shape[2]);
            throw std::out_of_range(s);
        }
        return _data[index];
    }

    // Aliases for at(size_t, size_t, size_t).
    typename std::vector<T>::reference atDiscreteCoordinates(size_t i, size_t j, size_t k) { return at(i, j, k); }
    typename std::vector<T>::const_reference atDiscreteCoordinates(size_t i, size_t j, size_t k) const
    {
        return at(i, j, k);
    }

    // Access to elements by discrete coordinates.
    // Does not check if coordinates are valid or not.
    typename std::vector<T>::reference operator()(size_t i, size_t j, size_t k)
    {
        return _data[_T.discreteToIndex(i, j, k)];
    }

    typename std::vector<T>::const_reference operator()(size_t i, size_t j, size_t k) const
    {
        return _data[_T.discreteToIndex(i, j, k)];
    }

    // Access to elements by real coordinates.
    // Throws std::out_of_range if coordinates are outside the grid.
    typename std::vector<T>::reference atRealCoordinates(double x, double y, double z)
    {
        size_t index;
        if (not _T.realToIndex(x, y, z, index))
        {
            std::string s = String::format(
                "Grid: invalid coordinates (%., %., %.) (Grid(size=%dx%dx%d, origin=(%., %., %.))", x, y, z,
                _T.shape[0], _T.shape[1], _T.shape[2], _T.origin[0], _T.origin[1], _T.origin[2]);
            throw std::out_of_range(s);
        }
        return _data[index];
    }

    typename std::vector<T>::const_reference atRealCoordinates(double x, double y, double z) const
    {
        size_t index;
        if (not _T.realToIndex(x, y, z, index))
        {
            std::string s = String::format(
                "Grid: invalid coordinates (%., %., %.) (Grid(size=%dx%dx%d, origin=(%., %., %.))", x, y, z,
                _T.shape[0], _T.shape[1], _T.shape[2], _T.origin[0], _T.origin[1], _T.origin[2]);
            throw std::out_of_range(s);
        }
        return _data[index];
    }

    // Gets a grid item using discrete coordinates.
    // Returns a pair:
    //    - bool is whether of not the coordinates are valid
    //    - pointer to item (or nullptr)
    std::pair<bool, T *> getItem(const size_t i, const size_t j, const size_t k)
    {
        bool isvalid = _T.isValidDiscreteCoordinates(i, j, k);
        if (isvalid)
            return std::make_pair(true, &(*this)(i, j, k));
        return std::make_pair(false, nullptr);
    }

    // Gets a grid item using real coordinates.
    // Returns a pair:
    //    - bool is whether of not the coordinates are valid
    //    - pointer to item (or nullptr)
    std::pair<bool, T *> getItem(const double x, const double y, const double z)
    {
        bool isvalid = _T.isValidRealCoordinates(x, y, z);
        if (isvalid)
            return std::make_pair(true, &atRealCoordinates(x, y, z));
        return std::make_pair(false, nullptr);
    }

    //
    // Iteration over grid items.
    //

    struct iterator
    {
        using value_type = T;
        using reference = T &;
        using pointer = T *;
        using difference_type = std::ptrdiff_t;
        using iterator_category = std::forward_iterator_tag;

        typename std::vector<T>::iterator iter;

        bool operator!=(const iterator & other) const { return iter != other.iter; }
        void operator++() { ++iter; }
        reference operator*() const { return *iter; }
    };

    struct const_iterator
    {
        using value_type = const T;
        using reference = const T &;
        using pointer = const T *;
        using difference_type = std::ptrdiff_t;
        using iterator_category = std::forward_iterator_tag;

        typename std::vector<T>::const_iterator iter;

        bool operator!=(const const_iterator & other) const { return iter != other.iter; }
        void operator++() { ++iter; }
        reference operator*() const { return *iter; }
    };


    // using const_iterator = typename __GridBase<const T>::iterator;

    constexpr auto begin() { return iterator{std::begin(_data)}; }
    constexpr auto end() { return iterator{std::end(_data)}; }

    constexpr const auto begin() const { return const_iterator{std::begin(_data)}; }
    constexpr const auto end() const { return const_iterator{std::end(_data)}; }


    struct enumerate_iterator
    {
        std::array<size_t, 3> shape;
        typename __GridBase<T>::iterator iter;
        size_t i, j, k;

        enumerate_iterator(std::array<size_t, 3> shape, typename __GridBase<T>::iterator iter)
            : shape(shape), iter(iter), i(0), j(0), k(0)
        {
        }

        bool operator!=(const enumerate_iterator & other) const { return iter != other.iter; }
        void operator++()
        {
            // Increments discrete coordinates according the the grid dimensions.
            k++;
            if (k == shape[2])
            {
                k = 0;
                j++;
                if (j == shape[1])
                {
                    j = 0;
                    i++;
                }
            }

            // Increments iterator to internal data container.
            ++iter;
        }
        constexpr auto operator*() const { return std::tie(i, j, k, *iter); }
    };

    constexpr auto enumerate()
    {
        struct wrapper
        {
            __GridBase<T> && grid;
            auto begin() { return enumerate_iterator(grid.getShape(), grid.begin()); }
            auto end() { return enumerate_iterator(grid.getShape(), grid.end()); }
        };

        return wrapper{std::forward<__GridBase<T>>(*this)};
    }

  protected:
    std::vector<T> _data;
    GridCoordinatesTransform _T;

    void __resize() { _data.resize(_T.size()); }
};

template <typename T> class GridBase : public __GridBase<T>
{
  public:
    using __GridBase<T>::__GridBase;

    T * OutOfGrid() { return &_outofgrid; }

  protected:
    T _outofgrid;
};

template <typename T> class GridBase<T *> : public __GridBase<T *>
{
  public:
    GridBase(size_t sizei, size_t sizej, size_t sizek, double deltax, double deltay, double deltaz, double offsetx,
             double offsety, double offsetz)
        : __GridBase<T *>(sizei, sizej, sizek, deltax, deltay, deltaz, offsetx, offsety, offsetz)
    {
        __init();
    }

    GridBase(std::array<double, 6> box, std::array<double, 3> spacing) : __GridBase<T *>(box, spacing) { __init(); }

    GridBase(double centerx, double centery, double centerz, double delta, double distance)
        : __GridBase<T *>(centerx, centery, centerz, delta, distance)
    {
        __init();
    }

    T * OutOfGrid() { return _outofgrid; }

  protected:
    T * _outofgrid;

    virtual void __init()
    {
        _outofgrid = new T();
        for (size_t i = 0; i < __GridBase<T *>::_data.size(); i++)
        {
            __GridBase<T *>::_data[i] = new T();
        }
    }
};

#endif // __GRIDBASE_H__
