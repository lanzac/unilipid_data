#ifndef _SPRINGNETWORK_H_
#define _SPRINGNETWORK_H_

#include "Constraint.h"
#include "ForceField.h"
#include "Grid.h"
#include "InsertionVector.h"
#include "Interactor.h"
#include "Particle.h"
#include "PotentialGrid.h"
#include "Selection.h"
#include "Spring.h"
#include "Vector3f.h"
#include "Vector3d.h"
#ifdef OPENGL_SUPPORT
#include "SpringNetworkViewer.h"
#endif
#ifdef FREESASA_SUPPORT
	#include "freesasa.h"
#endif
#include <cstdlib>
#include <cstring>
#include <stdio.h>
#include <vector>

#include <chrono>
#include <ctime>
#include <iostream>
#include <ratio>
using namespace std::chrono;

#include "RigidBody.h"

// #define FILTERSIZE 256
// #define MAXNBFILTER 256
// #define UNDEFINEDINDEX -1
// #define MAXEXTID 100000

using namespace std;

class Spring;
class Reduce;
class PDBTrajectoryWriter;
class XTCTrajWriter;
class CSVSampleWriter;
class InsertionVector;
class Interactor;
class SpringNetworkViewer;
class RigidBody;

class SpringNetwork
{
  public:
    SpringNetwork()
        : _interactor(nullptr), _initparticules(), _particules(), _staticparticules(), _dynamicparticules(),
          _chargedparticules(), _hydrophobicparticules(), _probeparticule(nullptr), _springs(), _timestep(1.0),
          _springenergy(0.0), _electrostaticenergy(0.0), _stericenergy(0.0), _kineticenergy(0.0), _impenergy(0.0),
          _showperf(false), _nbiter(0), _maxiter(100), _end(false), _pause(false), _stiffness(1),
          _viscosity(0.0), _springcutoff(-1.0), _caspringcutoff(-1.0), _stericcutoff(15.0), _electrostaticcutoff(16.0), _hydrophobiccutoff(15),
          _stericgrid(nullptr), _springgrid(nullptr), _electrostaticgrid(nullptr), _hydrophobicgrid(nullptr),
          _potentialgrid(nullptr), _densitygrid(nullptr), _bary(), _springenabled(false), _viscosityenabled(false),
          _impenabled(false), _insertionvectorenabled(false), _stericenabled(false), _electrostaticenabled(false),
          _electrostaticcoulombenabled(false), _electrostaticfieldenabled(false), _densitygridenabled(false),
          _hydrophobicityenabled(false), _probeenabled(false), _constraintenabled(false), _probestericenabled(false),
          _probeelectrostaticenabled(false), _probeelectrostaticcoulombenabled(false),
          _probeelectrostaticfieldenabled(false), _rigidbodyenabled(false), _createspringbetweenchain(true), _setnullchargeonstatic(false),
          _staticmode(false), _dynamicmode(true), _springgenerationctc(0.0), _oneiterationctc(0.0), _samplerate(100.0),
          _framerate(0.0), _gridscale(1.0), _ff(nullptr),
          _r(nullptr), _pdbtrajwriter(nullptr), _xtctrajwriter(nullptr), _samplewriter(nullptr), _insertionVector(nullptr),
          _selections(), _constraints(), _meanConstraintsDistances(0.0), _structid(_currentstructid)
    {
        _currentstructid++;
    }

    virtual ~SpringNetwork();

    // ================================================================================

    // Gets/Sets interator.
    void setInteractor(Interactor * interactor) { _interactor = interactor; }
    Interactor * getInteractor() const { return _interactor; }

    // Returns current number of iterations so far (read-only).
    int getNbIterations() const { return _nbiter; }

    // Gets/Sets maximum number of iteration.
    void setMaxIteration(int nbmaxiter) { _maxiter = nbmaxiter; }
    int getMaxIteration() const { return _maxiter; }

    // Gets/Sets timestep.
    void setTimeStep(double timestep) { _timestep = timestep; }
    double getTimeStep() const { return _timestep; }

    // Gets/Sets sample rate.
    void setSampleRate(double samplerate) { _samplerate = samplerate; }
    double getSampleRate() const { return _samplerate; }

    // Gets/Sets force field.
    ForceField * getForceField() const { return _ff; };
    void setForceField(ForceField * ff) { _ff = ff; }

    // Gets/Sets insertion vector.
    void setInsertionVector(std::string token1, std::string token2);
    InsertionVector * getInsertionVector() { return _insertionVector; }
    const InsertionVector * getInsertionVector() const { return _insertionVector; }

    // Returns current number of particle in hydrophobic core (read-only).
    int getNbInHydrophobicCore() const { return _nbinhydrophobiccore; }

    // Returns current number of particle in interface (read-only).
    int getNbInInterface() const { return _nbininterface; }

    // Returns current number of particle in hydrophilic phase (read-only).
    int getNbInHydrophilicPhase() const { return _nbinhydrophilicphase; }

    inline void setRigidBody(RigidBody *rb) { _rb = rb;}
    inline const RigidBody* getRigidBody() { return _rb;}

    // ================================================================================
    // Gets/Sets cutoffs

    // Gets/Sets steric cutoff.
    void setStericCutoff(double cutoff) { _stericcutoff = cutoff; }
    double getStericCutoff() const { return _stericcutoff; }

    // Gets/Sets electrostatic cutoff.
    void setElectrostaticCutoff(double cutoff) { _electrostaticcutoff = cutoff; }
    double getElectrostaticCutoff() const { return _electrostaticcutoff; }

    // Gets/Sets spring cutoff.
    void setSpringCutoff(double cutoff) { _springcutoff = cutoff; }
    double getSpringCutoff() const { return _springcutoff; }

    // Gets/Sets CA spring cutoff.
    void setCASpringCutoff(double cacutoff) { _caspringcutoff = cacutoff; }
    double getCASpringCutoff() const { return _caspringcutoff; }

    // Gets/Sets hydrophobicity cutoff.
    void setHydrophobicCutoff(double cutoff) { _hydrophobiccutoff = cutoff; }
    double getHydrophobicCutoff() const { return _hydrophobiccutoff; }

    // Gets/Sets grid scale.
    void setGridScale(double gridscale) { _gridscale = gridscale; }
    double getGridScale() const { return _gridscale; }

    // ================================================================================
    // Gets/Sets dynamic/static mode.

    bool getStaticMode() const { return _staticmode; }
    void setStaticMode(bool staticmode) { _staticmode = staticmode; }

    bool getDynamicMode() const { return _dynamicmode; }
    void setDynamicMode(bool dynamicmode) { _dynamicmode = dynamicmode; }

    // ================================================================================

    std::vector<Constraint *> getConstraints(void) { return _constraints; }

    // Gets/Sets flags for creating springs between chains.
    void setCreateSpringBetweenChain(bool b) { _createspringbetweenchain = b; }
    bool isCreateSpringBetweenChain() { return _createspringbetweenchain; }

    // Gets/Sets stiffness.
    void setStiffness(double stiffness);
    double getStiffness() const { return _stiffness; }

    // Gets/Sets viscosity.
    void setViscosity(double viscosity) { _viscosity = viscosity; }
    double getViscosity() const { return _viscosity; }

    // Returns frame rate (read-only).
    double getFrameRate() const { return _framerate; }

    // Returns energies (read-only).
    double getKineticEnergy() const { return _kineticenergy; }
    double getSpringEnergy() const { return _springenergy; }
    double getStericEnergy() const { return _stericenergy; }
    double getElectrostaticEnergy() const { return _electrostaticenergy; }
    double getIMPEnergy() const { return _impenergy; }
    void setIMPEnergy(double energy) { _impenergy = energy; }

    // ================================================================================
    // Gets/Sets grids.

    // Gets/Sets potential grid.
    void setPotentialGrid(PotentialGrid * grid) { _potentialgrid = grid; }
    PotentialGrid * getPotentialGrid() const { return _potentialgrid; }

    // Gets/Sets density grid.
    void setDensityGrid(PotentialGrid * grid) { _densitygrid = grid; }
    PotentialGrid * getDensityGrid() const { return _densitygrid; }

    // Gets/Sets steric grid.
    void setStericGrid(Grid * grid)
    {
        _stericgrid = grid;
        _stericgrid->setSpringNetwork(this);
    }

    Grid * getStericGrid() const { return _stericgrid; }

    // Gets/Sets electrostatic grid.
    void setElectrostaticGrid(Grid * grid)
    {
        _electrostaticgrid = grid;
        _electrostaticgrid->setSpringNetwork(this);
    }
    Grid * getElectrostaticGrid() const { return _electrostaticgrid; }

    // Gets/Sets spring grid.
    void setSpringGrid(Grid * grid)
    {
        _springgrid = grid;
        _springgrid->setSpringNetwork(this);
    }

    Grid * getSpringGrid() const { return _springgrid; }

    // Gets/Sets hydrophobicity grid.
    void setHydrophobicGrid(Grid * grid)
    {
        _hydrophobicgrid = grid;
        _hydrophobicgrid->setSpringNetwork(this);
    }

    Grid * getHydrophobicGrid() const { return _hydrophobicgrid; }

    // ================================================================================
    // Gets/Sets/Adds probe.
    Particle * getProbe() const { return _probeparticule; }
    void setProbe(Particle * probe);
    void addProbe();

    // ================================================================================
    // Adds/Removes springs to/from the spring network.

    // Adds a spring to the network.
    void addSpring(unsigned id1, unsigned id2, double equilibrium, double stiffness);
    void addSpring(unsigned id1, unsigned id2, double equilibrium);
    void addSpring(unsigned id1, unsigned id2);
    void addSpringWithStiffness(unsigned id1, unsigned id2, double stiffness);

    // Adds springs using a cutoff distance.
    bool addSpringsFromCutoff();
    bool addSpringsBetweenStructFromCutoff();
    bool addSpringsFromCutoffNaive(const std::vector<unsigned> & selection = std::vector<unsigned>());

    // Removes springs between two selections.
    int removeSpringsBetweenSelections(std::vector<int> sel1, std::vector<int> sel2);

    // ================================================================================
    // Adds/Removes particles to/from the network.

    // Adds a particle to the network.
    void addParticle(Particle * p);
    void addParticle(const Particle & p);
    void addInitParticle(Particle * p);

    // Removes all particles.
    void clearParticles(void);

    // Adds one or several particles to/from grid.
    void addParticleInGrid(unsigned index);
    void addAllParticlesInGrid();

    // Removes one or several particles to/from grid.
    void removeAllParticlesFromGrid();
    void removeParticleFromGrid(unsigned index);

    // ================================================================================
    // Gets springs/particles.

    // Returns ith spring in spring list.
    Spring * getSpring(unsigned index) const { return _springs[index]; }

    // Returns a spring using the particle ids.
    Spring * getSpringFromParticlesIds(int id1, int id2);

    // Returns ith particle in particle list.
    inline Particle * getParticle(unsigned index) const { return _particules[index]; }

    // Returns a particle using its extid (see Particle::getExtId)
    Particle * getParticleFromExtid(unsigned extid) const;

    // Returns a particle using its id (see Particle::getId)
    Particle * getParticleFromId(unsigned extid) const;

    // Returns the closest particle given some coordinates.
    Particle * getNearestParticleByCoords(double x, double y, double z, double radius) const;

    // Returns the farthest particle given some coordinates.
    Particle * getFarthestParticleByCoords(double x, double y, double z, double radius) const;

    // Returns the farthest particle given some coordinates.
    Particle * getFarthestParticleByCoords(double x, double y, double z) const;

    // ================================================================================
    // Barycentre methods.

    Vector3d computeBarycentre() const;
    Vector3d computeFarthestToBarycentre() const;
    Vector3d getBarycentre() const { return _bary; }
    void getBarycentre(double barycentre[3]) const;
    void setBarycentreToOrigin();

    // ================================================================================
    // Gets/Sets flags.

    void setPause(bool pause) { _pause = pause; }
    bool getPause() const { return _pause; }

    void enableSpring(bool b) { _springenabled = b; }
    bool isSpringEnabled() const { return _springenabled; }

    void enableViscosity(bool b) { _viscosityenabled = b; }
    bool isViscosityEnabled() const { return _viscosityenabled; }

    void enableSteric(bool b) { _stericenabled = b; }
    bool isStericEnabled() const { return _stericenabled; }

    void enableElectrostatic(bool b) { _electrostaticenabled = b; }
    bool isElectrostaticEnabled() const { return _electrostaticenabled; }

    void enableElectrostaticCoulomb(bool b) { _electrostaticcoulombenabled = b; }
    bool isElectrostaticCoulombEnabled() const { return _electrostaticcoulombenabled; }

    void enableElectrostaticField(bool b) { _electrostaticfieldenabled = b; }
    bool isElectrostaticFieldEnabled() const { return _electrostaticfieldenabled; }

    void enableIMP(bool b) { _impenabled = b; }
    bool isIMPEnabled() const { return _impenabled; }

    void enableDensityGrid(bool b) { _densitygridenabled = b; }
    bool isDensityGridEnabled() const { return _densitygridenabled; }

    void enableConstraint(bool b) { _constraintenabled = b; }
    bool isConstraintEnabled() const { return _constraintenabled; }

    void enableHydrophobicity(bool b) { _hydrophobicityenabled = b; }
    bool isHydrophobicityEnabled() const { return _hydrophobicityenabled; }

    void enableStericAndSpring(bool enablestericandspring);
    bool isStericAndSpringEnabled() const { return _stericandspringenabled; }

    void enableElectrostaticAndSpring(bool b) { _electrostaticandspringenabled = b; }
    bool isElectrostaticAndSpringEnabled() const { return _electrostaticandspringenabled; }

    void enableHydrophobicAndSpring(bool b) { _hydrophobicandspringenabled = b; }
    bool isHydrophobicAndSpringEnabled() const { return _hydrophobicandspringenabled; }

    void setNullChargeOnStatic(bool b) { _setnullchargeonstatic = b; }
    bool getNullChargeOnStatic() const { return _setnullchargeonstatic; }

    void enableRigidBody(bool b) { _rigidbodyenabled = b; }
    bool isRigidBodyEnabled() const { return _rigidbodyenabled; }

    // ================================================================================
    // Gets/Sets probe-specific flags.

    void enableProbe(bool b) { _probeenabled = b; }
    bool isProbeEnabled() const { return _probeenabled; }

    void enableProbeElectrostatic(bool b) { _probeelectrostaticenabled = b; }
    bool isProbeElectrostaticEnabled() const { return _probestericenabled; }

    void enableProbeElectrostaticCoulomb(bool b) { _probeelectrostaticcoulombenabled = b; }
    bool isProbeElectrostaticCoulombEnabled() const { return _probeelectrostaticcoulombenabled; }

    void enableProbeElectrostaticField(bool b) { _probeelectrostaticfieldenabled = b; }
    void enableProbeSteric(bool b) { _probestericenabled = b; }

    void enableInsertionVector(bool b) { _insertionvectorenabled = b; }
    bool isInsertionVectorEnabled() const { return _insertionvectorenabled; }

    bool isProbeElectrostaticFieldEnabled() const { return _probeelectrostaticfieldenabled; }
    bool isProbeStericEnabled() const;

    // ================================================================================
    Vector3d computeFarestToOrigin() const;

    bool writePDB(const char * pdbin, const char * pdbout);

    bool isSpring(unsigned id1, unsigned id2) const;

    double computeRMSD();
    virtual void run();

    unsigned getNumberOfSprings() const { return _springs.size(); }
    unsigned getNumberOfParticles() const { return _particules.size(); }

    double computeTotalMass();

    // ================================================================================
    // Returns subsets of particles.

    vector<Particle *> getParticles() const { return _particules; }
    vector<Particle *> getInitParticles() const { return _initparticules; }

    // Returns subsets of particle ids.
    vector<unsigned> getDynamicParticles() const { return _dynamicparticules; }
    vector<unsigned> getChargedParticles() const { return _chargedparticules; }
    vector<unsigned> getStaticParticles() const { return _staticparticules; }
    vector<unsigned> getHydrophobicParticles() const { return _hydrophobicparticules; }

    // ================================================================================
    // Gets/Sets writers.

    void setTrajectoryWriter(PDBTrajectoryWriter * writer) { _pdbtrajwriter = writer; }
    PDBTrajectoryWriter * getTrajectoryWriter() const { return _pdbtrajwriter; }

    inline void setXTCTrajectoryWriter(XTCTrajWriter * writer) { _xtctrajwriter = writer; }
    inline XTCTrajWriter * getXTCTrajWriter() const { return _xtctrajwriter; }

    void setCSVSampleWriter(CSVSampleWriter * writer) { _samplewriter = writer; }
    CSVSampleWriter * getCSVSampleWriter() const { return _samplewriter; }

    // ================================================================================
    // Selection methods.

    void addParticleInSelection(const string & selection, unsigned particleid);
    void addSelection(const string & selection);
    void addSelection(Selection * selection);
    Selection * getSelection(const string & selection) { return _selections[selection]; }
    // ================================================================================
    // Run-related methods.

    virtual void initRun();
    virtual void endRun();
    virtual void idleRun();

    // ================================================================================
#ifdef FREESASA_SUPPORT
    void callFreeSASA();
    double* getSASA() const { return _sasa;}
    void configFreeSASA();

    inline void setFreeSASA_Dynamic(bool isDynamic) {_isFreeSASA_Dynamic = isDynamic;};
    inline void setFreeSASA_Step(unsigned step) {_freeSASA_step = step;};
    inline void setFreeSASA_Alg(std::string alg) {_freeSASA_alg = alg;};
    inline void setFreeSASA_Resolution(unsigned res) {_freeSASA_res = res;};
    inline void setFreeSASA_ProbeRad(double probe_radius) {_freeSASA_proberadius = probe_radius;};
    inline void setFreeSASA_RadiiClassifier(std::string radii_classifier) {_freeSASA_radiiclassifier = radii_classifier;};
    inline void setFreeSASA_nthreads(int nthreads) {_freeSASA_nthreads = nthreads;};

    inline bool getFreeSASA_Dynamic() const { return _isFreeSASA_Dynamic;};
    inline unsigned getFreeSASA_Step() const { return _freeSASA_step;};
    inline std::string getFreeSASA_Alg() const { return _freeSASA_alg;};
    inline unsigned getFreeSASA_Resolution() const { return _freeSASA_res;};
    inline double getFreeSASA_ProbeRad() const { return _freeSASA_proberadius;};
    inline std::string getFreeSASA_RadiiClassifier() const { return _freeSASA_radiiclassifier;};
    inline int getFreeSASA_nthreads() const { return _freeSASA_nthreads;};

    inline void setFreeSASA_params(freesasa_parameters *params) {_freesasa_params = params;};
    inline freesasa_parameters* getFreeSASA_params() const { return _freesasa_params;};

    inline void setFreeSASA_classifier(const freesasa_classifier* classifier) {_freesasa_classifier = classifier;};
    inline const freesasa_classifier* getFreeSASA_classifier() const { return _freesasa_classifier;};

    inline void setFreeSASA_radii(double* radii) {_freesasa_radii = radii;};
    inline double* getFreeSASA_radii() const { return _freesasa_radii;};

    inline double getSASA_total() { return _sasa_total;};	
#endif
    void integrateParticles(double &kineticenergyparticle);
    // Starts/Ends timer.
    void startTimer(string clock_name);
    long long elapsedTimer(string clock_name) const;

    void setParticleCharges(const double value);

    void setParticleStatic(const bool isstatic);

    void addConstraint(Constraint * constraint) { _constraints.push_back(constraint); }

    void applyConstraints();

    virtual void getParticlePosition(unsigned i, double position[3]) const;

    virtual void setForce(unsigned i, double force[3]);

    bool isEnd() const { return _end; }
    void setEnd(bool end)
    {
        if (!_end)
            _end = end;
    }

#ifdef OPENGL_SUPPORT
    SpringNetworkViewer * _viewer;
    void setSpringNetworkViewer(SpringNetworkViewer * viewer) { _viewer = viewer; }
    SpringNetworkViewer * getSpringNetworkViewer() const { return _viewer; }
#endif

    void merge(const SpringNetwork & other);

  protected:
    Interactor * _interactor;
    std::vector<Particle *> _initparticules;
    std::vector<Particle *> _particules;

    std::vector<unsigned> _staticparticules;
    std::vector<unsigned> _dynamicparticules;
    std::vector<unsigned> _chargedparticules;
    std::vector<unsigned> _hydrophobicparticules;

    Particle * _probeparticule;

    std::vector<Spring *> _springs;

    double _timestep;
    double _csv_timestep;
    double _springenergy;
    double _electrostaticenergy;
    double _stericenergy;
    double _kineticenergy;
    double _impenergy;
    int _nbinhydrophobiccore;
    int _nbininterface;
    int _nbinhydrophilicphase;

    bool _showperf;

    int _nbiter;
    int _maxiter;
    bool _end;
    bool _pause;

    double _stiffness;
    double _viscosity;

    double _springcutoff;
    double _caspringcutoff;
    double _stericcutoff;
    double _electrostaticcutoff;
    double _hydrophobiccutoff;

    Grid * _stericgrid;
    Grid * _springgrid;
    Grid * _electrostaticgrid;
    Grid * _hydrophobicgrid;

    PotentialGrid * _potentialgrid;
    PotentialGrid * _densitygrid;

    Vector3d _bary;

    bool _springenabled;
    bool _viscosityenabled;

    bool _impenabled;
    bool _insertionvectorenabled;

    bool _stericenabled;
    bool _electrostaticenabled;
    bool _electrostaticcoulombenabled;
    bool _electrostaticfieldenabled;
    bool _densitygridenabled;
    bool _hydrophobicityenabled;
    bool _probeenabled;

    bool _constraintenabled;

    bool _probestericenabled;
    bool _probeelectrostaticenabled;
    bool _probeelectrostaticcoulombenabled;
    bool _probeelectrostaticfieldenabled;

    bool _stericandspringenabled;
    bool _vanderwaalsandspringenabled;
    bool _electrostaticandspringenabled;
    bool _hydrophobicandspringenabled;

    bool _rigidbodyenabled;
    RigidBody *_rb;

    bool _createspringbetweenchain;

    bool _setnullchargeonstatic;
    bool _staticmode;
    bool _dynamicmode;

    double _springgenerationctc;
    double _oneiterationctc;
    double _samplerate;
    double _framerate;

    double _gridscale;

    map<string, high_resolution_clock::time_point> _startcounts;

    ForceField * _ff;
    Reduce * _r;

    PDBTrajectoryWriter * _pdbtrajwriter;
    XTCTrajWriter * _xtctrajwriter;
    CSVSampleWriter * _samplewriter;

    InsertionVector * _insertionVector;

    unordered_map<string, Selection *> _selections;

    vector<Constraint *> _constraints;
    double _meanConstraintsDistances;

    static unsigned _currentstructid;
    unsigned _structid;

    // Writes current positions using trajectory writers.
    void _writeNextStep();

    // Returns true if it's time to display current frame data.
    bool _isTimeToLogData() const { return _nbiter % ((unsigned)_samplerate) == 0; }

    // Displays current frame informations on logging channel.
    void _displayFrameData();

    // Calculates frame rate.
    void _updateFrameRate();

    // Returns true if the run is endless (i.e. no maximum number of iterations).
    bool _isInfiniteRun() { return _maxiter < 0; }

    // Returns true if reached the maximum number of iterations.
    bool _hasReachedEndOfRun() { return not _isInfiniteRun() and _nbiter == _maxiter; }
#ifdef FREESASA_SUPPORT
    double *_sasa;
    double _sasa_total;
    bool _isFreeSASA_Dynamic;
    unsigned _freeSASA_step;
    std::string _freeSASA_alg;
    unsigned _freeSASA_res;
    double _freeSASA_proberadius;
    std::string _freeSASA_radiiclassifier;
    freesasa_parameters *_freesasa_params;
    const freesasa_classifier *_freesasa_classifier;
    double *_freesasa_radii;
    int _freeSASA_nthreads;
#endif

  private:
    void reset();
};

#endif
