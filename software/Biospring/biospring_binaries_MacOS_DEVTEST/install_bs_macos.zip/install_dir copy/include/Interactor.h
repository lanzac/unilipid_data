#ifndef _INTERACTOR_H_
#define _INTERACTOR_H_

#include "SpringNetwork.h"
#include <cstring>

class Interactor
{
  public:
    Interactor() : _springnetwork(nullptr), _nbpositions(0), _positions(nullptr), _forces(nullptr), _sasa(nullptr), _start(false) {}

    virtual ~Interactor()
    {
        delete[] _positions;
        delete[] _forces;
    }

    void setSpringNetwork(SpringNetwork * springnetwork) { _springnetwork = springnetwork; }
    SpringNetwork * getSpringNetwork() const { return _springnetwork; }

    virtual int getNbPositions() const { return _nbpositions; }

    virtual void setPositions(float * positions) { memcpy(_positions, positions, sizeof(float) * _nbpositions * 3); }

    virtual double * getForces() const { return _forces; }

    virtual void start() { _start = true; }
    virtual void stop() { _start = false; }
    virtual void synchronize();

    virtual void init();



  protected:
    SpringNetwork * _springnetwork;
    int _nbpositions;
    float * _positions;
    double * _forces;

    float * _sasa;
    const char *_sasa_name;

    bool _start;

    float * _floatsend;
    int   _floatsend_size;
    const char *_floatsend_name;

    float *_trimp;
    const char *_trimp_name;

    float *_computed_particles_forces;
    int _computed_particles_forces_size;
    const char *_computed_particles_forces_name;

    std::string _float_dataname_to_send;
    std::vector<std::string> _float_dataname_list;

    int   *_infoS;

    int   *_intsend;
    int _intsend_size;
    const char *_intsend_name;

    void _setNbPositions(int nbpositions);


	void _resetForces(size_t size);
	void _resetPositions(size_t size);
  void _resetSASA(size_t size);

	void _reserveForces(size_t size);
	void _reservePositions(size_t size);
  void _reserveSASA(size_t size);

	void _eraseForces() { delete[] _forces; _forces = nullptr; }
	void _erasePositions() { delete[] _positions; _positions = nullptr; }
  void _eraseSASA() { delete[] _sasa; _sasa = nullptr; }
};

#endif
