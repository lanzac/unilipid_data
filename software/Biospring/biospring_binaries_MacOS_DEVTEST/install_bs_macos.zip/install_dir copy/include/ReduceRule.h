#ifndef _REDUCERULE_H_
#define _REDUCERULE_H_

#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

class Reduce;

class ReduceRule
{
  public:
    ReduceRule(const std::string & name, const std::string & resname)
        : _name(name), _resname(resname), _atomnames(), _isallatom(false)
    {
    }

    ReduceRule() : ReduceRule("", "") {}

    void setName(const std::string & name) { _name = name; }
    const std::string & getName() const { return _name; }

    void setResidueName(const std::string & resname) { _resname = resname; };
    const std::string & getResidueName() const { return _resname; }

    const std::unordered_set<std::string> & getAtomNames() const { return _atomnames; }

    void setAllAtom(bool allatom) { _isallatom = allatom; }
    bool isAllAtom() const { return _isallatom; }

    size_t getNumberOfAtoms(void) const { return _atomnames.size(); }

    void addAtom(const std::string & atomname) { _atomnames.insert(atomname); };

    bool hasAtomNamed(const std::string name) const { return _atomnames.find(name) != _atomnames.end(); }

    void print() const;

  private:
    std::string _name;
    std::string _resname;
    std::unordered_set<std::string> _atomnames;

    bool _isallatom;
};

#endif
