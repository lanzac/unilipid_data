#ifndef __RIGIDBODY_H__
#define __RIGIDBODY_H__

#include <Vector3d.h>
#include <Vector3d.h>
#include "Quaternion.h"
#include <cmath>
#include <iostream>
#include "InsertionVector.h"
#include "matrix.h"
#include <string>
#include "random.hpp"
using Random = effolkronium::random_static;

#define STATE_SIZE 13
#define NUMSUBSTEPS 2

class InsertionVector;


// http://www.cs.cmu.edu/~baraff/sigcourse/notesd1.pdf

class RigidBody
{
  public:

    RigidBody()
      : pos_ini(0.0),
        cur_pos(0.0)
    {}
    void fetchParameters();
    RigidBody(SpringNetwork * sp, vector<unsigned int> particles, vector<unsigned int> interactionParticles = vector<unsigned int>(0));

    unsigned rbid;

    std::vector<unsigned> _rbparticules;
    std::vector<unsigned> _interactionParticles;

    std::vector<unsigned> _selfHydrophilicParticles;
    std::vector<unsigned> _interactionHydrophilicParticles;
    
  
    // Initialization
    void init();
    double computeTotalMass();
    Vector3d computeBarycentre() const;
    void computeAllLocalPositions();
    Matrix computeIbody(Vector3d com);
    /* ---------------------------------------------------------------------------------------------------------------*/

    // IMPALA Sampling
    double pos_ini;
    double pos_fin;
    double cur_pos;
    double _inser_angle;
    double inser_angle_ini;
    double _roll_angle;
    Vector3d iv_vec_rot;
    double min_roll_energy;

    void initImpalaSampling();
    void updateImpalaSampling(int nbiter, double timestep);
    Vector3d getImpalaSamplingParticlePosition(Particle *p, int ind);
    void solveImpalaSampling(int nbiter);
    /* ---------------------------------------------------------------------------------------------------------------*/

    // Monte Carlo sampling
    bool _is_monte_carlo_enabled;

    Vector3d _montecarlo_current_position;
    Vector3d _montecarlo_current_angles;

    Vector3d _montecarlo_next_translation_vector; // Keep the current translation to apply
    Vector3d _montecarlo_next_angles;  // Track the current 2 axis (x and y) angles to apply [+/- _random_rotation_norm, +/- _random_rotation_norm]

    double _prev_impenergy;

    void initMonteCarlo(double random_translation_norm, double random_rotation_norm);
    Vector3d getRandomTranslation() {return Vector3d::RandomVector3d(_montecarlo_translation_norm);};
    double getRandomRotation() {return Random::get({-_montecarlo_rotation_norm, _montecarlo_rotation_norm});};
    Vector3d getMonteCarloParticlePosition(Particle *p, int ind);
    void solveMonteCarlo();
    /* ---------------------------------------------------------------------------------------------------------------*/
    // Rigid body dynamics computation
    
    int applydepthrestraint = 0;
    double depth_restraint = 0;
    double depth_restraint_scaling = 0;
    void applyDepthRestraint();

    int applyanglerestraint = 0;
    double angle_restraint = 0;
    double angle_restraint_scaling = 0;
    void applyAngleRestraint();
    
    int withoutRotational = 0;
    Vector3d external_force;
    Vector3d external_torque;

    void applyHydrophobicRestraint();

    void solve();

    static void computeParticleForceAndTorque(Particle *p);
    static void solveAll();
    static void resetRigidBodiesForceAndTorque();
    static void integrateParticleVelocity(Particle *p, int ind, double timestep); // Called in SpringNetwork::integrateParticles

    /* ---------------------------------------------------------------------------------------------------------------*/

    Matrix createVector3Matrix();
    void updateVector3Matrix(Matrix &m, Vector3d v);

    // Get Set
    void setPos(Vector3d pos) { _pos = pos; }
    Vector3d getPos() const { return _pos; }
    Vector3d getForce() const { return _force; }
    Vector3d getTorque() const { return _torque; }
    Vector3d getOmega() const { return _omega_v; }
    static vector<RigidBody*> getCollection();

    double _montecarloenergy; // Energy associated to each bodie


    // Rigid Body properties
    static bool _impalasamplingenabled;
    static bool _splitchainsenabled;
    // Monte Carlo
    static bool _montecarloenabled;
    static double _montecarlo_translation_norm; // random translation to apply each step in Å
    static double _montecarlo_rotation_norm;    // random rotation to apply each step in °
    static double _montecarlo_temperature;
    static vector<RigidBody*> collection;


  private:
    SpringNetwork * _spn;
    std::vector<Vector3d> _p0;
    double _dt;        
    double _dmax; // Maximum distance from barycentre to the farthest atom in the structure
    // time step size

    /* ------------------------------------------------ */

    /* Constant quantities */
    double     _mass;                       /* mass M */
    Matrix     _ibody,                      /* Ibody */
               _ibodyinv;                   /* I−1 body (inverse of Ibody) */

    /* State variables */
    Vector3d   _pos;                       /* x(t) is _com at initial state*/

    Quaternion _orientation;

    /* Derived quantities (auxiliary variables) */            
    Vector3d   _v;                         /* v(t) */
    Vector3d   _a;                         /* a(t) */
    Vector3d   _alpha;                         /* angular acceleration */
    Vector3d   _L;                         /* angular momentum */

    Vector3d   _omega_v;                    /* ω(t) */

    /* Computed quantities */
    Vector3d   _force,                     /* F(t) */
               _torque;                    /* τ(t) */
};


#endif