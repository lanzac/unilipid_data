#ifndef _REDUCE_H_
#define _REDUCE_H_

#include <string>
#include <vector>

#include <unordered_map>

using namespace std;

#include "ParticleGroup.h"
#include "ReduceRule.h"

class ForceFieldData;

class Reduce
{
  public:
    Reduce()
        : _reducerules(), _groups(), _reducerulenametoreduceruleid(), _atomnametoatomid(), _resnametoresid(),
          _reduceruleidtoreducerulename(), _atomidtoatomname(), _residtoresname(), _oneparticleperrule(false)
    {
    }

    void addReduceRule(const ReduceRule & rule) { _reducerules.push_back(rule); }

    size_t getNumberOfRules() const { return _reducerules.size(); }

    ReduceRule getReduceRule(const std::string & name) const { return _reducerules.at(getReduceRuleIdFromName(name)); }

    bool hasRuleNamed(const std::string & name) const
    {
        return _reducerulenametoreduceruleid.find(name) != _reducerulenametoreduceruleid.end();
    }

    void addReduceRuleName(const string & reducerulename);
    void addResidueName(const string & resname);
    void addAtomName(const string & atomname);

    int getReduceRuleIdFromName(const string & reducerulename) const;
    int getAtomIdFromName(const string & atomname) const;
    int getResidueIdFromName(const string & resname) const;
    const string getReduceRuleNameFromId(size_t id) const;
    const string getResidueNameFromId(size_t id) const;
    const string getAtomNameFromId(size_t id) const;

    vector<ReduceRule *> getReduceRulesByResName(const string & resname);

    void addGroup(ParticleGroup *);

    void reduce(ForceFieldData * ff);
    void checkOneParticlePerRule();
    bool OneParticlePerRule();
    void print();

  private:
    vector<ReduceRule> _reducerules;
    vector<ParticleGroup *> _groups;

    unordered_map<string, size_t> _reducerulenametoreduceruleid;
    unordered_map<string, size_t> _atomnametoatomid;
    unordered_map<string, size_t> _resnametoresid;

    unordered_map<size_t, string> _reduceruleidtoreducerulename;
    unordered_map<size_t, string> _atomidtoatomname;
    unordered_map<size_t, string> _residtoresname;
    bool _oneparticleperrule;
};

#endif
