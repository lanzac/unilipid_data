#ifndef __GRID_H__
#define __GRID_H__

#include "Cell.h"
#include "GridBase.h"

class SpringNetwork;

class Grid : public GridBase<Cell>
{
  public:
    Grid(size_t sizei, size_t sizej, size_t sizek, double deltax, double deltay, double deltaz, double offsetx,
         double offsety, double offsetz)
        : GridBase(sizei, sizej, sizek, deltax, deltay, deltaz, offsetx, offsety, offsetz), _springnetwork(NULL)
    {
        init();
    }

    Grid() : Grid(0, 0, 0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0) {}

    Grid(double centerx, double centery, double centerz, double delta, double distance)
        : GridBase(centerx, centery, centerz, delta, distance), _springnetwork(NULL)
    {
        init();
    }

    virtual ~Grid() {}

    void init();

    void setSpringNetwork(SpringNetwork * spn) { _springnetwork = spn; }

    void addParticle(size_t index);
    void removeParticle(size_t index);

    void empty();

    Cell * getCellOutOfGrid() { return OutOfGrid(); }

    void print() const;

  protected:
    SpringNetwork * _springnetwork;
};

#endif // __GRID_H__
