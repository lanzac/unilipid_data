#ifndef __INSERTION_VECTOR_H__
#define __INSERTION_VECTOR_H__

#include "Particle.h"
#include "Vector3d.h"

class SpringNetwork;

class InsertionVector
{
  public:
    InsertionVector(SpringNetwork * sp, std::string token1, std::string token2)
        : _sp(sp), _token1(token1), _token2(token2), _aa1(0), _aa2(0),_p1(NULL),
          _p2(NULL), _insertionVector(Vector3d(0.0, 0.0, 0.0)),
          _insertionAngle(0.0)
    {
    }

    Particle * getParticle(unsigned i) const;

    double getAngle() const { return _insertionAngle; }

    Vector3d getVector() const { return _insertionVector; }

    double getInsertionDepth() const;

    bool Initialize();
    bool parseInsertionVector(size_t &particleid, const std::string &token);
    bool computeVector();
    void computeAngle();

  protected:
    SpringNetwork * _sp;
    std::string _token1;
    std::string _token2;
    unsigned _aa1;
    unsigned _aa2;
    Particle * _p1;
    Particle * _p2;
    Vector3d _insertionVector;
    double _insertionAngle;
};

#endif // __INSERTION_VECTOR_H__
