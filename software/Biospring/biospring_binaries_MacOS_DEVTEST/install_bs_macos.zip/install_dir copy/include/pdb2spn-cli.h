
#include "SpringNetwork.h"
#include "argparse.h"

#include <string>
#include <vector>

namespace biospring
{

namespace pdb2spncli
{

//
// Handles command-line parsing as well as argument storage for program pdb2spn.
//
class CommandLineArguments : public biospring::argparse::CommandLineArgumentsBase
{
  public:
    // I/O paths.
    std::string pathTopology;
    std::string pathForceField;
    std::string pathGroup;
    std::vector<std::string> pathOutputList;

    // User options.
    double cutoff;
    double cacutoff;
    double stiffness;
    double charge;
    bool isStatic;
    bool ignoreDuplicates;
    bool ignoreMissing;

    // Constructor with default value for command line parameters.
    CommandLineArguments(int argc, const char * const argv[]);
    CommandLineArguments() : CommandLineArguments(0, nullptr) {};

    // Implements abstract methods from parent class.
    void printArgumentValue() const;
    void parseCommandLine();

    // Access to private flags.
    bool isUserOutput() const { return _isUserOutput; }
    bool isUserCharge() const { return _isUserCharge; }

    void setUserOutput(bool b) { _isUserOutput = b; }
    void setUserCharge(bool b) { _isUserCharge = b; }

    void useUserOutput() { setUserOutput(true); }
    void useUserCharge() { setUserCharge(true); }

  protected:
    // Internal parameters;
    bool _isUserCharge; // flag indicating whether the --charge option has been used
    bool _isUserOutput; // flag indicating whether the -o, --output option has been used
};

void reduceToCoarseGrain(SpringNetwork & spn, const CommandLineArguments & args);

int main(int argc, char ** argv);

} // namespace pdb2spncli

} // namespace biospring
