
#ifndef __GRID_COORDINATES_TRANSFORM_H__
#define __GRID_COORDINATES_TRANSFORM_H__

#include <array>
#include <cmath>


// Transforms grid coordinates in many ways, from discrete to real and from 3D to 1D.
struct GridCoordinatesTransform
{
    std::array<size_t, 3> shape;
    std::array<double, 3> origin;
    std::array<double, 3> spacing;

    // Constructs from size, spacing and origin.
    GridCoordinatesTransform(size_t sizei, size_t sizej, size_t sizek, double deltax, double deltay, double deltaz,
                             double offsetx, double offsety, double offsetz)
        : shape({sizei, sizej, sizek}), origin({offsetx, offsety, offsetz}), spacing({deltax, deltay, deltaz})
    {
    }

    // Empty constructor, everything's set at 0.
    GridCoordinatesTransform() : GridCoordinatesTransform(0, 0, 0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0) {}

    // Constructs from box coordinates and spacing.
    GridCoordinatesTransform(std::array<double, 6> box, std::array<double, 3> spacing)
        : GridCoordinatesTransform(0, 0, 0, spacing[0], spacing[1], spacing[2], box[0], box[1], box[2])
    {
        setShape({size_t((box[3] - box[0]) / spacing[0]), size_t((box[4] - box[1]) / spacing[1]),
                  size_t((box[5] - box[2]) / spacing[2])});
    }

    // Constructs from box center, spacing, and box size.
    GridCoordinatesTransform(double centerx, double centery, double centerz, double delta, double distance)
        : GridCoordinatesTransform(0, 0, 0, delta, delta, delta, 0, 0, 0)
    {
        size_t size = size_t(((distance / delta) + 1) * 4);
        double offset = (double(size / 2)) * delta;

        setShape({size, size, size});
        setOrigin({centerx - offset, centery - offset, centerz - offset});
    }

    void setShape(const std::array<size_t, 3> & a)
    {
        shape[0] = a[0];
        shape[1] = a[1];
        shape[2] = a[2];
    }

    void setOrigin(const std::array<double, 3> & a)
    {
        origin[0] = a[0];
        origin[1] = a[1];
        origin[2] = a[2];
    }

    void setSpacing(const std::array<double, 3> & a)
    {
        spacing[0] = a[0];
        spacing[1] = a[1];
        spacing[2] = a[2];
    }

    // Returns the total number of elements in the grid.
    size_t size() const { return shape[0] * shape[1] * shape[2]; }

    // Returns true if (i, j, k) is within the grid.
    bool isValidDiscreteCoordinates(const int i, const int j, const int k) const
    {
        return ((i >= 0 and i < (signed) shape[0]) and
                (j >= 0 and j < (signed) shape[1]) and
                (k >= 0 and k < (signed) shape[2]));
    }

    // Returns true if (x, y, z) is within the grid.
    bool isValidRealCoordinates(const double x, const double y, const double z) const
    {
        return ((x >= origin[0] and x < origin[0] + shape[0] * spacing[0]) and
                (y >= origin[1] and y < origin[1] + shape[1] * spacing[1]) and
                (z >= origin[2] and z < origin[2] + shape[2] * spacing[2]));
    }

    // Transforms discrete coordinates to real coordinates.
    // Returns whether coordinates are valid (within grid) or not.
    bool discreteToReal(size_t i, size_t j, size_t k, double * x, double * y, double * z) const
    {
        *x = ((double)i) * spacing[0] + origin[0];
        *y = ((double)j) * spacing[1] + origin[1];
        *z = ((double)k) * spacing[2] + origin[2];
        return isValidDiscreteCoordinates((signed) i, (signed) j, (signed) k);
    }

    // Transforms real coordinates to discrete coordinates.
    // Returns whether coordinates are valid (within grid) or not.
    bool realToDiscrete(double x, double y, double z, size_t * i, size_t * j, size_t * k) const
    {
        *i = size_t(std::floor((x - origin[0]) / spacing[0] + 0.5));
        *j = size_t(std::floor((y - origin[1]) / spacing[1] + 0.5));
        *k = size_t(std::floor((z - origin[2]) / spacing[2] + 0.5));
        return isValidDiscreteCoordinates(*i, *j, *k);
    }

    // Gets the 1D index from 3D discrete coordinates.
    // Returns whether the index is valid (within grid) or not.
    bool discreteToIndex(size_t i, size_t j, size_t k, size_t & index) const
    {
        bool isValid = isValidDiscreteCoordinates(i, j, k);
        if (isValid)
            index = discreteToIndex(i, j, k);
        return isValid;
    }

    // Gets the 1D index from 3D discrete coordinates.
    // Does not check whether coordinates are valid or not.
    size_t discreteToIndex(size_t i, size_t j, size_t k) const
    {
        return i * shape[1] * shape[2] + j * shape[2] + k;
    }

    // Gets the 1D index from 3D real coordinates.
    // Returns whether the index is valid (within grid) or not.
    bool realToIndex(double x, double y, double z, size_t & index) const
    {
        size_t i, j, k;
        bool isValid = realToDiscrete(x, y, z, &i, &j, &k);
        if (isValid)
            discreteToIndex(i, j, k, index);
        return isValid;
    }

    // == Legacy API ====================================================================
    bool getDiscreteCoordsFromRealCoords(double x, double y, double z, size_t * i, size_t * j, size_t * k) const
    {
        return realToDiscrete(x, y, z, i, j, k);
    }

    bool getRealCoordsFromDiscreteCoords(size_t i, size_t j, size_t k, double * x, double * y, double * z) const
    {
        return discreteToReal(i, j, k, x, y, z);
    }
};

#endif // __GRID_COORDINATES_TRANSFORM_H__
