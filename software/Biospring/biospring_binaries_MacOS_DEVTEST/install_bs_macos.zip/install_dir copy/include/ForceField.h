#ifndef _FORCEFIELD_H_
#define _FORCEFIELD_H_

#include "ParticleProperty.h"
#include <string>

#include <unordered_map>

#include <map>

using namespace std;

#include "Vector3d.h"
#include <vector>

// typedef unordered_map <std::string, ParticleProperty *> propertiesmap;
typedef map<std::string, ParticleProperty *> propertiesmap;

class ForceField
{
  public:
    static const double PI;
    static const double VACUUMPERMITIVITY;
    static const double BOLTZMANJPERK;
    static const double BOLTZMANEVPERK;
    static const double ELECTRONCHARGETOCOULOMB;
    static const double COULOMB2ELECTRONCHARGE;
    static const double ANGSTROM2METER;
    static const double METER2ANGSTROM;
    static const double MINIMALDISTANCEELECTROCUTOFF;
    static const double MINIMALDISTANCEVDWCUTOFF;
    static const double ELECTRONVOLTTOJOULE;
    static const double JOULETOELECTRONVOLT;
    static const double UMA2KILOGRAM;
    static const double KCALPERMOL2ELECTRONVOLPERTATOM;
    static const double AVOGADRONUMBER;
    static const double KJOULE2KCAL;
    static const double KCAL2KJOULE;
    static const double DALTON2UMA;
    static const double DALTON2KILOGRAM;
    static const double KILOGRAM2DALTON;
    static const double NEWTON2DALTONANGSTROMPERFEMTOSECOND2;

    static const double KJOULE2JOULE;
    static const double JOULE2KJOULE;
    static const double SECOND2FEMTOSECOND;
    static const double FEMTOSECOND2SECOND;

    static const double GLOBALKINETICENERGYCONVERT;
    static const double GLOBALIMPFORCECONVERT;
    static const double GLOBALSPRINGFORCECONVERT;
    static const double GLOBALELECTROSTATICFORCECONVERT;

    ForceField();
    virtual ~ForceField();

    void addPropertiesFromName(const std::string name, ParticleProperty * pp);
    ParticleProperty * getPropertiesFromName(const std::string & name);
    ParticleProperty getPropertiesFromName(const std::string & name) const;
    void print();

    size_t getNumberOfProperties() const { return _propertiesfromname.size(); }

    bool hasProperty(const std::string & name) const
    {
        return _propertiesfromname.find(name) != _propertiesfromname.end();
    }

    virtual double computeElectrostaticForceModule(double charge1, double charge2, double distance);
    virtual double computeStericForceModule(double radius1, double radius2, double epsilon1, double epsilon2,
                                           double distance);
    virtual double computeSpringForceModule(double distance, double stiffness, double equilibrium);

    virtual double computeIMPForceModule(double x, double y, double z, double surface, double transfer);
    virtual double computeHydrophobicityForceModule(double hydrophobicity1, double hydrophobicity2, double distance);

    virtual double computeElectrostaticEnergy(double charge1, double charge2, double distance);
    virtual double computeElectrostaticFieldEnergy(double potential, double charge);
    virtual double computeStericEnergy(double radius1, double radius2, double epsilon1, double epsilon2, double distance);
    virtual double computeSpringEnergy(double distance, double stiffness, double equilibrium);
    virtual double computeIMPEnergy(double x, double y, double z, double surface, double transfer);
    virtual double computeHydrophobicityEnergy(double hydrophobicity1, double hydrophobicity2, double distance);

    // void setElectrostaticScale(double electrostaticscale);
    void setCoulombScale(double coulombscale);
    void setForceFieldScale(double forcefieldscale);

    void setStericScale(double stericscale);
    void setSpringScale(double springscale);
    void setIMPScale(double impscale);
    void setImpDoubleMembraneOffset(double impdoublemembraneoffset);
    void setHydrophobicityScale(double hydrophobicityscale);

    // double getElectrostaticScale() ;
    double getCoulombScale();
    double getForceFieldScale();

    double getStericScale();
    double getSpringScale();
    double getImpDoubleMembraneOffset();
    double getIMPScale();
    double getHydrophobicityScale();

    double getDielectric() const;
    void setDielectric(double dielectric);

    std::vector<Vector3d> membrane_mesh_vertices; 
    std::vector<Vector3d> membrane_mesh_normals;
    int _nearest_vertex_index;
    int _membrane_mesh_resolution;
    bool isMeshMembraneVerticesArrayEmpty() const { return membrane_mesh_vertices.size() == 0; }
    bool isMeshMembraneNormalsArrayEmpty() const { return membrane_mesh_normals.size() == 0; }
    int getNearestVertexIndex(Vector3d position);
    Vector3d getVertexPositionByIndex(int index) const { return membrane_mesh_vertices[index]; }
    Vector3d getNormalVectorByIndex(int index) const { return membrane_mesh_normals[index]; }

  protected:
    double _stericscale;
    // double _electrostaticscale;
    double _springscale;
    double _impscale;
    double _impdoublemembraneoffset;
    double _forcefieldscale;
    double _coulombscale;
    double _hydrophobicityscale;
    double _dielectric;

  private:
    propertiesmap _propertiesfromname;
};

#endif
