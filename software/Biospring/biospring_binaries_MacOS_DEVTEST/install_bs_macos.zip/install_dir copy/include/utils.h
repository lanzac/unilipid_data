
//
// Various utilities.
//

#ifndef __UTILS_H__
#define __UTILS_H__

#include <fstream>
#include <sstream>
#include <regex>
#include <sstream>
#include <string>
#include <stdarg.h>
#include <sys/stat.h>
#include <utility>
#include <vector>

#include "logging.h"

namespace path
{

//
// Returns true if a path has an extension.
//
inline bool hasExtension(const std::string & s)
{
    return s.find(".") != std::string::npos;
}

//
// Returns true if a path has not an extension.
//
inline bool hasNoExtension(const std::string & s)
{
    return not hasExtension(s);
}

//
// Splits a path into a pair (root, extension).
//
inline std::pair<std::string, std::string> splitExtension(const std::string & s)
{
    std::string prefix, ext;
    size_t i = s.rfind('.', s.length());
    if (i != std::string::npos)
    {
        prefix = s.substr(0, i);
        ext = s.substr(i + 1, s.length() - i);
    }
    else
    {
        prefix = s;
    }
    std::pair<std::string, std::string> out;
    out.first = prefix;
    out.second = ext;
    return out;
}

//
// Returns a path extension.
//
inline std::string getExtension(std::string path)
{
    size_t n = path.find_last_of('.');
    if (n == std::string::npos)
        return "";
    return path.substr(path.find_last_of('.') + 1, path.size());
}
} // namespace path

namespace File
{
//
// Opens a file in read mode.
// Dies if:
//     - cannot open it,
//     - file is empty (optionnal).
//
inline void openread(const std::string & path, std::ifstream & infile, bool diesIfEmpty = false)
{
    if (path.empty())
    {
        biospring::logging::die("openread: empty file name");
    }
    infile.open(path);
    if (not infile)
    {
        biospring::logging::die("can't open file: '%s'", path.c_str());
    }
    if (diesIfEmpty and infile.peek() == std::ifstream::traits_type::eof())
    {
        biospring::logging::die("%s: empty file", path.c_str());
    }
}

//
// Opens a file in write mode.
// Dies if:
//     - cannot open it,
//     - file is empty (optionnal).
//
inline void openwrite(const std::string & path, std::ofstream & outfile)
{
    outfile.open(path);
    if (not outfile)
    {
        biospring::logging::die("can't open file: '%s'", path.c_str());
    }
}

// Returns true if a file exists.
inline bool exists(const std::string & path)
{
    struct stat buffer;
    return (stat(path.c_str(), &buffer) == 0);
}
} // namespace File

namespace String
{

// default implementation
template <typename T> struct TypeName
{
    static const char* Get() { return typeid(T).name(); }
};

template <> struct TypeName<int>
{
    static const char* Get() { return "int"; }
};

template <> struct TypeName<size_t>
{
    static const char* Get() { return "size_t"; }
};

template <> struct TypeName<double>
{
    static const char* Get() { return "double"; }
};

template <> struct TypeName<std::string>
{
    static const char* Get() { return "std::string"; }
};




// Returns the concatenation of strings present in input container and separated by delimiter.
inline std::string join(const std::vector<std::string> & tokens, const std::string & delimiter = "")
{
    std::string s = "";
    for (std::vector<std::string>::const_iterator p = tokens.begin(); p != tokens.end(); ++p)
    {
        s += *p;
        if (p != tokens.end() - 1)
            s += delimiter;
    }
    return s;
}

// Returns a vector of the words in the string s using a delimiter.
inline std::vector<std::string> split(const std::string & s, const std::string & delimiter)
{
    std::string buffer(s);
    std::vector<std::string> tokens;
    size_t pos = 0;
    while ((pos = buffer.find(delimiter)) != std::string::npos)
    {
        tokens.push_back(buffer.substr(0, pos));
        buffer.erase(0, pos + delimiter.length());
    }
    tokens.push_back(buffer);
    return tokens;
}

// Returns a vector of the words in the string s using the
// space as delimiter.
inline std::vector<std::string> split(const std::string & s)
{
    std::vector<std::string> tokens;
    std::istringstream iss(s);
    copy(std::istream_iterator<std::string>(iss), std::istream_iterator<std::string>(),
         std::back_inserter<std::vector<std::string>>(tokens));
    return tokens;
}

inline std::string toupper(const std::string & s)
{
    std::string out = s;
    std::transform(out.begin(), out.end(), out.begin(), ::toupper);
    return out;
}

inline std::string tolower(const std::string & s)
{
    std::string out = s;
    std::transform(out.begin(), out.end(), out.begin(), ::tolower);
    return out;
}

// String formatting.
// From http://stackoverflow.com/questions/2342162/stdstring-formatting-like-sprintf
inline std::string format(const std::string fmt, ...)
{
    int size = 100;
    std::string str;
    va_list ap;
    while (1) {
        str.resize(size);
        va_start(ap, fmt);
        int n = vsnprintf((char *)str.c_str(), size, fmt.c_str(), ap);
        va_end(ap);
        if (n > -1 && n < size) {
            str.resize(n);
            return str;
        }
        if (n > -1)
            size = n + 1;
        else
            size *= 2;
    }
    return str;
}

//
// String trim functions.
// Source: https://www.techiedelight.com/trim-string-cpp-remove-leading-trailing-spaces/
//

// Trim from left.
inline std::string ltrim(const std::string & s) { return std::regex_replace(s, std::regex("^\\s+"), std::string("")); }

// Trim from right.
inline std::string rtrim(const std::string & s) { return std::regex_replace(s, std::regex("\\s+$"), std::string("")); }

// Trim from both sides.
inline std::string trim(const std::string & s) { return ltrim(rtrim(s)); }

// Converts a string to any type.
// Adapted from http://forums.codeguru.com/showthread.php?231054-C-String-How-to-convert-a-string-into-a-numeric-type
template <class T> inline bool from_string(T & t, const std::string & s)
{
    std::istringstream iss(s);
    return !(iss >> t).fail();
}

template <> inline bool from_string(bool & t, const std::string & s)
{
    bool success = true;
    const std::string str = String::tolower(s);
    if (str == "true" or str == "1" or str == "on")
        t = true;
    else if (str == "false" or str == "0" or str == "off")
        t = false;
    else
        success = false;
    return success;
}

template <class T> inline T parse_string(const std::string & s)
{
    T value;
    if (not from_string(value, s))
        throw format("cannot convert string \"%s\" to %s", s.c_str(), TypeName<T>::Get()).c_str();
    return value;
}

} // namespace String

#endif
