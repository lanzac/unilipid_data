#ifdef MDDRIVER_SUPPORT

#ifndef _INTERACTORMDDRIVER_H_
#define _INTERACTORMDDRIVER_H_

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

#include "Interactor.h"
#include "imd_interface.h"

#define FILTERSIZE 256
#define LOGFILENAMESIZE 256


class InteractorMDDriver : public Interactor
	{
	public : 
		InteractorMDDriver();
		virtual ~InteractorMDDriver();
		void setPort(unsigned port);
		void setWait(unsigned wait);
		void setDebug(unsigned debug);
		void setLog(const char * logfilename);
		void setForceScale(float forcescale);
		
		virtual void start();
		virtual void stop();
		virtual void synchronize();
	
	protected : 
		char _IMDlogfilename[LOGFILENAMESIZE];
		int    _IMDdebug ;
		FILE * _IMDlog;
		int    _IMDstop  ;
		int _IMDmode ; 
		int _IMDwait ;
		int _IMDport ;
		float     _IMDforcescale ;
		IMDEnergies _IMDenergies;
		int _nbforces;
		int * _particleforceids; 
		float * _particleforces;

		int _customFloatSwitcher;

		char *_custom_int_dataname;
    	int *_custom_int;
		int _nbint;

		char *_custom_float_dataname;
    	float *_custom_float;
		int _nbfloat;
			
		pthread_t _imdthreads;
		pthread_mutex_t mutex;

		static int iterate( InteractorMDDriver * imdl);
		static void init( InteractorMDDriver * imdl);
		static void end( InteractorMDDriver * imdl);	

		static void  * runthread(void * userdata);
		virtual void init();
		
		
		
	};

#endif

#endif
