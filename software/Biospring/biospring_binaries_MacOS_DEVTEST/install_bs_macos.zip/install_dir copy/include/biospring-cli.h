
#ifndef __BIOSPRING_CLI__H
#define __BIOSPRING_CLI__H

#include "argparse.h"
#include "version.h"

#include <string>
#include <set>

namespace biospring
{

namespace biospringcli
{

// Stores MDDriver parameters.
struct MDDriverParameters
{
    bool wait = true;
    unsigned port = 3000;
    unsigned debug = 0;
    std::string logpath = "";
    double forcescale = 1.0;
};

// Stores FreeSASA parameters.
struct FreeSASAParameters
{
    bool isDynamic = false;
    unsigned step = 1000; // for dynamic FreeSASA
    std::string alg = "sr"; // Default Shrake-Rupley algorithm.
    unsigned res = -1;
    double probe_radius = 1.4;
    std::string radii_classifier = "default_classifier";
    int n_threads = 2;
};

//
// Handles command-line parsing as well as argument storage for program biospring.
//
class CommandLineArguments : public biospring::argparse::CommandLineArgumentsBase
{
  public:
    // I/O paths.
    std::string pathTopology;
    std::string pathConfig;
#ifdef OPENCL_SUPPORT
    bool openclenabled = true;
#else
    bool openclenabled = false;
#endif
    MDDriverParameters mddriverParam;
    FreeSASAParameters freesasaParam;

    CommandLineArguments() : CommandLineArgumentsBase(0, nullptr) {}
    CommandLineArguments(int argc, const char * const argv[]);

    // Overrides abstract functions.
    void printArgumentValue() const;
    void parseCommandLine(int argc, const char * const * const argv);
    void parseCommandLine();

    bool checkDeprecated(const std::string & arg);

    // Other public functions.
    static std::string getVersionString() { return "biospring " + biospring::VERSION_STRING; }

  protected:
    static const std::set<std::string> _deprecatedArguments;
};


int main(int argc, char ** argv);
inline std::string getDescriptionString() { return CommandLineArguments().getDescriptionString(); }
inline std::string getVersionString() { return CommandLineArguments().getVersionString(); }

} // namespace biospringcli

} // namespace biospring


#endif // __BIOSPRING_CLI__H