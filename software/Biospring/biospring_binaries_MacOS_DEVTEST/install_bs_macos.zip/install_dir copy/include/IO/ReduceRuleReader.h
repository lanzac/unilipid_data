#ifndef _REDUCEREADER_H_
#define _REDUCEREADER_H_

#include <string>
#include <vector>

#include "IO/ReaderBase.h"
#include "Reduce.h"
#include "ReduceRule.h"

class ReduceRuleReader : public ReaderBase
{
  public:
    ReduceRuleReader() : ReaderBase(), _reduce(nullptr) {}
    ReduceRuleReader(const std::string & path) : ReaderBase(path), _reduce(nullptr) {}
    ReduceRuleReader(const char * const path) : ReaderBase(path), _reduce(nullptr) {}

    ~ReduceRuleReader() {}

    Reduce * getReduce() const { return _reduce; }
    void setReduce(Reduce * const red) { _reduce = red; }

    void read();

  private:
    Reduce * _reduce;
};

#endif
