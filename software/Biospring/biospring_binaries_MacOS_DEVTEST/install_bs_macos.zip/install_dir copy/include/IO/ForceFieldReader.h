#ifndef _FORCEREADER_H_
#define _FORCEREADER_H_

#include "ForceField.h"
#include "IO/ReaderBase.h"

class ForceFieldReader : public ReaderBase
{
  public:
    ForceFieldReader() : ReaderBase(), _forcefield(nullptr) {}
    ForceFieldReader(const std::string & path) : ReaderBase(path), _forcefield(nullptr) {}
    ForceFieldReader(const char * const path) : ReaderBase(path), _forcefield(nullptr) {}

    ForceField * getForceField() const { return _forcefield; }
    void setForceField(ForceField * const ff) { _forcefield = ff; }

    void read();

  private:
    ForceField * _forcefield;
};

#endif
