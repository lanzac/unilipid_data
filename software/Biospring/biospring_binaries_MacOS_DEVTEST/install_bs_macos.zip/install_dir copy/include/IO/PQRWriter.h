#ifndef _PQRWRITER_H_
#define _PQRWRITER_H_

#define UNDEFINEDINDEX -1

#include "PDBWriter.h"

class PQRWriter : public PDBWriter
{
  public:
    PQRWriter(const std::string & path, const SpringNetwork * const spn) : PDBWriter(path, spn) {}
    PQRWriter(const char * const path, const SpringNetwork * const spn) : PDBWriter(path, spn) {}
    PQRWriter() : PQRWriter("", nullptr) {}

    void writeModel(size_t modelid) override;
};

#endif
