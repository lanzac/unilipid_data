#ifndef __NETCDFWRITER_H__
#define __NETCDFWRITER_H__

#include "WriterBase.h"

#include <netcdf>

using netCDF::NcFile;

class NetCDFWriter : public TopologyWriterBase
{
  public:
    NetCDFWriter(const std::string & path, const SpringNetwork * const spn) : TopologyWriterBase(path, spn) {}
    NetCDFWriter(const char * const path, const SpringNetwork * const spn) : TopologyWriterBase(path, spn) {}
    NetCDFWriter() : NetCDFWriter("", nullptr) {}

    NcFile * safeOpenBinary();

    void write();
    void writeBinary();

  protected:

    void _writeHeaderCDL();
    void _writeParticleDataCDL();
    void _writeSpringDataCDL();

  private:
};

#endif // __NETCDFWRITER_H__
