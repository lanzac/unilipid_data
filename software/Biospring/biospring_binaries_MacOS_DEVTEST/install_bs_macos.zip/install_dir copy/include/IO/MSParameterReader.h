#ifndef _MSPARAMETERREADER_H_
#define _MSPARAMETERREADER_H_

#include <string>

#include "MSParameterBioSpring.h"
#include "ReaderBase.h"
#include "SpringNetwork.h"

class MSParameterReader : public ReaderBase
{
  public:
    MSParameterReader() : ReaderBase(), _spn(nullptr) {}
    MSParameterReader(const std::string & path) : ReaderBase(path), _spn(nullptr) {}
    MSParameterReader(const char * const path) : ReaderBase(path), _spn(nullptr) {}

    void read();

    SpringNetwork * getSpringNetwork() const { return _spn; }
    void setSpringNetwork(SpringNetwork * const spn) { _spn = spn; }

    biospring::MSParameter::MSParameterBioSpring getParameters() const { return _params; }

    // Get a parameter.
    template <typename T> T get(const std::string & param) const;

    // Special getter for "steric" type parameter.
    std::string getSteric() const;

    // Returns true if a parameter has been initialized.
    bool isInitialized(const std::string & param) const { return _params[param].initialized(); }

    // Prints parameters to stdout.
    void dump() const
    {
        _params.dump();
    }

  protected:
    SpringNetwork * _spn;
    biospring::MSParameter::MSParameterBioSpring _params;

    static std::string type_name(const std::string & name);

    static bool isCommentLine(const std::string & line) { return line.substr(0, 1) == "#"; }
    static bool isEmptyLine(const std::string & line) { return line.size() == 0; }
    static bool isDataLine(const std::string & line) { return not(isCommentLine(line) or isEmptyLine(line)); }
    bool isValidParameter(const std::string & param) { return _params.isAllowedParameter(param); }
    static std::array<std::string, 2> splitLine(const std::string & line, const size_t lineid);

    void _initialize();
    void _initializeForceField();
    void _initializeElectrostatic();
    void _initializeDensityGrid();
    void _initializeProbe();
    void _initializePDBTraj();
    void _initializeXTCTraj();
    void _initializeCSVSampling();
    void _initializeConstraints();
    void _initializeSelections();
    void _initializeInsertionVector();
    void _initializeRigidBody();
    bool _parseInsertionVector(size_t &particleid, const std::string &token);
};

#endif // _MSPARAMETERREADER_H_
