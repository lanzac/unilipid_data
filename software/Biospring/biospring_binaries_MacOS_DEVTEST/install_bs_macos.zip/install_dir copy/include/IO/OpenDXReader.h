#ifndef _OPENDXREADER_H_
#define _OPENDXREADER_H_

#include "IO/ReaderBase.h"
#include "PotentialGrid.h"

#include <fstream>
#include <string>

class OpenDXReader : public ReaderBase
{
  public:
    OpenDXReader() : ReaderBase(), _grid(nullptr) {}
    OpenDXReader(const std::string & path) : ReaderBase(path), _grid(nullptr) {}
    OpenDXReader(const char * const path) : ReaderBase(path), _grid(nullptr) {}
    ~OpenDXReader() {}

    void read();

    PotentialGrid * getGrid(void) const { return _grid; }
    void setGrid(PotentialGrid * const grid) { _grid = grid; }

  protected:
    void readSize();
    void readOrigin();
    void readScalingFactors();
    void readGrid();

  private:
    PotentialGrid * _grid;
};

#endif
