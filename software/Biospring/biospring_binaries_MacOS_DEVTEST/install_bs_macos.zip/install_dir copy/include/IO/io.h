
#include "SpringNetwork.h"

#include <string>
#include <vector>

namespace biospring
{

namespace io
{
void readTopology(const std::string & path, SpringNetwork & spn);
void writeTopology(const std::string & path, const SpringNetwork * const spn);
void writeTopology(const vector<string> & outputfiles, const SpringNetwork * const spn);
} // namespace io

} // namespace biospring
