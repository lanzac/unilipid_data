// Defines MSParameterBioSpring, that holds the actual list of parameters expected
// to run a BioSpring simulation.

#ifndef __MSPARAMETERSBIOSPRING_H__
#define __MSPARAMETERSBIOSPRING_H__

#include "MSParameter.h"

namespace biospring
{

namespace MSParameter
{

class MSParameterBioSpring : public MSParametersBase
{
  public:
    MSParameterBioSpring() : MSParametersBase()
    {
        // Simulation parameters.
        ParameterCollection sim("sim", "Simulation parameters");
        sim.insert(Parameter("nbsteps", "-1"));
        sim.insert(Parameter("timestep", "0.01"));
        sim.insert(Parameter("samplerate", "100"));
        sim.insert(ScaleParameter("grid", "1.0")); // gridscale
        insert(sim);

        // Energy.
        insert(EnergyParameterCollection("spring", "Spring energy calculation parameters"));

        EnergyParameterCollection steric("steric","Steric energy calculation parameters""15.0","1.0");
        steric.insert(Parameter("steric", "linear"));
        insert(steric);

        insert(EnergyParameterCollection("hydrophobicity", "Hydrophobicity parameters", "15.0", "1.0"));
        insert(EnergyParameterCollection("coulomb", "Electrostatic energy calculation parameters", "16.0", "1.0"));

        // Impala.
        insert(ParameterCollection("imp", "Impala parameters", true, true)); // switchable, scalable

        // Rigid body
        ParameterCollection rigidbody("rigidbody", "Rigid body parameters", true, false); // enablerigidbody
        rigidbody.insert(SwitchParameter("impalasampling", "false"));                     // enableimpalasampling
        rigidbody.insert(SwitchParameter("splitchains", "false"));                        // enablesplitchains
        rigidbody.insert(SwitchParameter("montecarlo", "false"));                         // enablemontecarlo
        rigidbody.insert(Parameter("montecarlotranslation", "1.0"));
        rigidbody.insert(Parameter("montecarlorotation", "1.0"));
        rigidbody.insert(Parameter("montecarlotemperature", "298.15"));
        insert(rigidbody);

        // Insertion vector.
        insert(SwitchableParameterCollection("insertionvector", "Insertion vector parameters", ""));

        // Viscosity.
        insert(SwitchableParameterCollection("viscosity", "Viscosity parameters", "1.0")); // viscosity, enableviscosity

        // Output trajectories.
        insert(TrajectoryParameterCollection("pdbtraj", "PDB trajectory parameters",
                                             "traj.pdb")); // pdbtrajfilename, pdbtrajfreq
        insert(TrajectoryParameterCollection("xtctraj", "XTC trajectory parameters",
                                             "traj.xtc")); // xtctrajfilename, xtctrajfreq

        // Special case here: CSV trajectory parameters prefix is "csvsample" instead of "csvtraj".
        ParameterCollection csvsample("csvsample", "CSV Trajectory parameters", true, false); // enablecsvsample
        csvsample.insert(PathParameter("csvsample", "sample.csv"));                           // csvsamplefilename
        csvsample.insert(FrequencyParameter("csvsample", "100"));                             // csvsamplefreq
        insert(csvsample);

        // Grids.
        insert(GridParameterCollection("potentialgrid", "Potential grid parameters", "",
                                       true)); // enablepotentialgrid, potentialgridscale, potentialgridfilename
        insert(GridParameterCollection("densitygrid", "Density grid parameters", "",
                                       false)); // enabledensitygrid, densitygridfilename
  

        // Probe.
        ParameterCollection probe("probe", "Probe parameters", true, false); // enableprobe
        probe.insert(SwitchParameter("probesteric", "false"));               // enableprobesteric
        probe.insert(SwitchParameter("probeelectrostatic", "false"));        // enableprobeelectrostatic
        probe.insert(Parameter("proberadius", "1.0"));
        probe.insert(Parameter("probecharge", "0.0"));
        probe.insert(Parameter("probemass", "1.0"));
        probe.insert(Parameter("probeepsilon", "1.0"));
        probe.insert(Parameter("probex", "1.0"));
        probe.insert(Parameter("probey", "1.0"));
        probe.insert(Parameter("probez", "1.0"));
        insert(probe);

        // Constraints.
        // ParameterCollection constraints("constraints", "Constraint parameters", true); // switchable, not scalable
        // constraints.insert(Parameter("constraints", ""));
        // constraints.insert(Parameter("selection1", ""));
        // constraints.insert(Parameter("selection2", ""));
        // insert(constraints);

        // Miscelleaneous parameters.
        ParameterCollection misc("misc", "Miscelleaneous parameters");
        misc.insert(Parameter("dielectric", "1.0"));
        insert(misc);
    }
};

} // namespace MSParameter
} // namespace biospring

#endif // __MSPARAMETERSBIOSPRING_H__
