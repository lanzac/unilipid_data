

#ifndef __XTCTRAJWRITER_H__
#define __XTCTRAJWRITER_H__

#include <string>
#include "xdrfile.h"
#include "WriterBase.h"

class XTCTrajWriter : public TrajectoryWriterBase
{
  public:
    XTCTrajWriter(const std::string & path, const SpringNetwork * const spn) : TrajectoryWriterBase(path, spn), _xdr(nullptr), _step(0) { _timestep = 0; }
    XTCTrajWriter(const char * const path, const SpringNetwork * const spn) : TrajectoryWriterBase(path, spn), _xdr(nullptr), _step(0) { _timestep = 0; }
    XTCTrajWriter() : XTCTrajWriter("", nullptr) {}

    ~XTCTrajWriter() { if (_xdr) xdrfile_close(_xdr); }

    void write() override { writeNextStep(); }

    void update();
    void close();
    void writeNextStep();
    void safeOpen();

  protected:
    XDRFILE * _xdr;
    size_t _step;
};

#endif // __XTCTRAJWRITER_H__
