//
// Defines the ReaderBase and TopologyReaderBase classes.
//
// Every Reader class should inherit from those class.
//

#ifndef __READER_BASE__
#define __READER_BASE__

#include <fstream>
#include <string>

#include "SpringNetwork.h"
#include "utils.h"

class ReaderBase
{
  public:
    ReaderBase() {}
    ReaderBase(const std::string & path) { setFileName(path); }
    ReaderBase(const char * const path) { setFileName(path); }
    virtual ~ReaderBase() {}
    void setFileName(const char * const path) { _filename = path; }
    void setFileName(const std::string & path) { _filename = path; }
    std::string & getFileName(void) { return _filename; }
    const std::string & getFileName(void) const { return _filename; }

    virtual void read() = 0;

    // Open file for reading.
    // Dies if something goes wrong.
    void safeOpen() { File::openread(_filename, _instream, true); }

    // Closes the file.
    void close() { _instream.close(); }

  protected:
    std::string _filename;
    std::ifstream _instream;
};

class TopologyReaderBase : public ReaderBase
{
  public:
    TopologyReaderBase() : ReaderBase(), _spn(0) {}
    TopologyReaderBase(const std::string & path) : ReaderBase(path), _spn(0) {}
    TopologyReaderBase(const char * const path) : ReaderBase(path), _spn(0) {}

    void setSpringNetwork(SpringNetwork * const spn) { _spn = spn; }
    SpringNetwork * getSpringNetwork(void) { return _spn; }
    const SpringNetwork * const getSpringNetwork(void) const { return _spn; }

  protected:
    SpringNetwork * _spn;
};

#endif