//
// Defines the WriterBase class.
//
// Every Reader class should inherit from those class.
//

#ifndef __WRITER_BASE__
#define __WRITER_BASE__

#include <fstream>
#include <string>

#include "SpringNetwork.h"
#include "utils.h"

class WriterBase
{
    public:
        WriterBase() {}
        WriterBase(const std::string & path): _filename(path) {}
        WriterBase(const char * const path) { setFileName(path); }
        virtual ~WriterBase() { if (_ostream.is_open()) _ostream.close(); }

        void setFileName(const char * const path) { _filename = path; }
        void setFileName(const std::string & path) { _filename = path; }

        std::string & getFileName(void) { return _filename; }
        const std::string & getFileName(void) const { return _filename; }

        virtual void write() = 0;

        // Open file for writing.
        // Dies if something goes wrong.
        void safeOpen() { if (not _ostream.is_open()) File::openwrite(_filename, _ostream); }


    protected:
        std::string _filename;
        std::ofstream _ostream;
};

class TopologyWriterBase : public WriterBase
{
  public:
    TopologyWriterBase(const std::string & path, const SpringNetwork * const spn) : WriterBase(path), _spn(spn) {}
    TopologyWriterBase(const char * const path, const SpringNetwork * const spn) : WriterBase(path), _spn(spn) {}

    void setSpringNetwork(const SpringNetwork * const spn) { _spn = spn; }
    const SpringNetwork * const getSpringNetwork(void) const { return _spn; }

  protected:
    const SpringNetwork * _spn;
};

class TrajectoryWriterBase : public TopologyWriterBase
{
  public:
    TrajectoryWriterBase(const std::string & path, const SpringNetwork * const spn) : TopologyWriterBase(path, spn), _timestep(0) {}
    TrajectoryWriterBase(const char * const path, const SpringNetwork * const spn) : TopologyWriterBase(path, spn), _timestep(0) {}

    size_t getTimeStep() const { return _timestep; }
    size_t getNumberOfStepsBetweenFrames() { return getTimeStep(); }

    void setTimeStep(const size_t n) { _timestep = n; }
    void setNumberOfStepsBetweenFrames(const size_t n) { setTimeStep(n); }

    bool isTimeToWrite(size_t currentTime) const { return currentTime % _timestep == 0; }

  protected:
    size_t _timestep;  // number of steps between frames
};

#endif