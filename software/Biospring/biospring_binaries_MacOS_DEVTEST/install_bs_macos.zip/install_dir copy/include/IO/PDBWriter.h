#ifndef _PDBWRITER_H_
#define _PDBWRITER_H_

#define UNDEFINEDINDEX -1

#include "WriterBase.h"

class PDBWriter : public TrajectoryWriterBase
{
  public:
    PDBWriter(const std::string & path, const SpringNetwork * const spn) : TrajectoryWriterBase(path, spn), _isconnect(false) {}
    PDBWriter(const char * const path, const SpringNetwork * const spn) : TrajectoryWriterBase(path, spn), _isconnect(false) {}
    PDBWriter() : PDBWriter("", nullptr) {}

    virtual void write();
    virtual void writeModel(size_t modelid);

    inline void setIsConnect(bool b) { _isconnect = b; }

  protected:
    bool _isconnect;

    static void replaceEndOfLineBySpace(char * linebuf, unsigned size);
    static void fillStringWithChar(char * linebuf, unsigned size, char mycar);

  private:
};

#endif
