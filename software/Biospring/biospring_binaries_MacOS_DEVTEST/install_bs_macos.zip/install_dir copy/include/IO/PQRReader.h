
#ifndef __PQRREADER_H__
#define __PQRREADER_H__

#include "PDBReader.h"

class PQRReader : public PDBReader
{
    public:
        void read();
        static Particle parseAtomLine(const std::string & line);
};

#endif
