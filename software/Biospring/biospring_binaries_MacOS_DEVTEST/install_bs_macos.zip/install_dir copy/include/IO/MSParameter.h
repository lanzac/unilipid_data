// Defines Parameter, ParameterCollection, MSParametersBase and BioSpringMSParameters classes.

// See class BioSpringMSParameters to the actual definition of parameters used
// in BioSpring configuration files.

#ifndef __MSPARAMETER_H__
#define __MSPARAMETER_H__

#include <array>
#include <exception>
#include <iostream>
#include <limits>
#include <map>
#include <set>
#include <string>
#include <typeinfo>
#include <vector>

#include "utils.h"

namespace biospring
{

namespace MSParameter
{

class DuplicateMSParameters : public std::runtime_error
{
  public:
    DuplicateMSParameters(const std::string & param)
        : std::runtime_error("Parameters have the same name (which is not allowed): '" + param + "'")
    {
    }
};

class type_error : public std::runtime_error
{
  public:
    type_error(const std::string & param, const std::string & expected)
        : std::runtime_error("cannot convert string to " + expected + ": '" + param + "'")
    {
    }
};

class invalid_parameter_error : public std::out_of_range
{
  public:
    invalid_parameter_error(const std::string & param)
        : std::out_of_range("trying to access parameter \"" + param + "\" which does not exists")
    {
    }
};

static inline std::string type_name(const std::string & name)
{
    if (name == "i")
        return "int";
    if (name == "f")
        return "double";
    if (name == "d")
        return "double";
    if (name == "b")
        return "bool";
    return "x";
}

static std::string switchName(const std::string & name) { return "enable" + name; }
static std::string scaleName(const std::string & name) { return name + "scale"; }
static std::string frequencyName(const std::string & name) { return name + "freq"; }
static std::string pathName(const std::string & name) { return name + "filename"; }
static std::string cutoffName(const std::string & name) { return name + "cutoff"; }

class Parameter
{
  public:
    Parameter(std::string name, std::string value) : _name(name), _value(value), _initialized(false) {}
    Parameter() : _name(), _value(), _initialized(false) {}

    bool initialized() const { return _initialized; }
    void initialize() { _initialized = true; }
    void reset()
    {
        _value = "";
        _initialized = false;
    }

    void setName(const std::string & name) { _name = name; }
    std::string getName() const { return _name; }

    // Sets parameter's value and marks it has initialized.
    void set(const std::string & value)
    {
        _value = value;
        _initialized = true;
    }

    // Prints parameter to stdout.
    void dump() const
    {
        std::cout << _name << " = " << _value << std::endl;
    }

    // Sets a parameter's value without marking it as initialized.
    // Intented to be used only when setting a parameters default value.
    void setDefault(const std::string & value) { _value = value; }

    std::string getRawValue() const { return _value; }

    template <typename T> T getValue() const
    {
        T result = std::numeric_limits<T>::lowest();
        bool success = String::from_string<T>(result, _value);
        if (not success)
        {
            throw biospring::MSParameter::type_error(_value, type_name(typeid(result).name()));
        }
        return result;
    }

  protected:
    std::string _name;
    std::string _value;
    bool _initialized;
};

// Returns a parameter's string value.
// Removes quotes from raw string.
template <> inline std::string Parameter::getValue() const
{
    std::string s(_value);
    s.erase(remove(s.begin(), s.end(), '\"'), s.end());
    return s;
}

class SwitchParameter : public Parameter
{
  public:
    SwitchParameter(const std::string & suffix, const std::string & enabled = "false")
        : Parameter(switchName(suffix), enabled)
    {
    }
};

class ScaleParameter : public Parameter
{
  public:
    ScaleParameter(const std::string & prefix, const std::string & value = "1.0") : Parameter(scaleName(prefix), value)
    {
    }
};

class FrequencyParameter : public Parameter
{
  public:
    FrequencyParameter(const std::string & prefix, const std::string & value = "1")
        : Parameter(frequencyName(prefix), value)
    {
    }
};

class PathParameter : public Parameter
{
  public:
    PathParameter(const std::string & prefix, const std::string & value = "") : Parameter(pathName(prefix), value) {}
};

class CutoffParameter : public Parameter
{
  public:
    CutoffParameter(const std::string & prefix, const std::string & value = "1.0")
        : Parameter(cutoffName(prefix), value)
    {
    }
};


class ParameterCollection
{
  public:
    std::string name;
    std::string help;
    std::map<std::string, Parameter> parameters;
    bool hasSwitch;
    bool hasScale;

    ParameterCollection(const std::string & name, const std::string help, bool hasSwitch = false, bool hasScale = false)
        : name(name), help(help), parameters(), hasSwitch(hasSwitch), hasScale(hasScale)
    {
        if (hasSwitch)
            insert(SwitchParameter(name));

        if (hasScale)
            insert(ScaleParameter(name));
    }

    // Access to parameters value thanks to brackets.
    Parameter at(const std::string & key) const { return parameters.at(key); }
    Parameter operator[](const std::string & key) const { return parameters.at(key); }
    Parameter & operator[](const std::string & key) { return parameters[key]; }

    // Inserts a parameter in the collection.
    // Throws a DuplicateParameterException if a parameter with the same name
    // is already in the collection.
    void insert(const Parameter & p)
    {
        if (contains(p.getName()))
        {
            throw DuplicateMSParameters(p.getName());
        }
        parameters[p.getName()] = p;
    }

    // Inserts a collection into another (merge).
    void insert(const ParameterCollection & other)
    {
        // one-by-one insertion to make sure an exception in thrown when
        // duplicate parameters are found.
        for (const auto & item : other.parameters)
            insert(item.second);
    }

    // Removes a parameters from the collection.
    // Does nothing if the collections does not contain `param`.
    void erase(const std::string & param) { parameters.erase(param); }

    // Replaces a parameter with another.
    void replace(const std::string & target, const Parameter & p)
    {
        erase(target);
        insert(p);
    }

    // Sets a parameter's value.
    // This method should be called only when reading the parameter file,
    // has it will flag the Parameter has `initialized`.
    void set(const std::string & key, const std::string & value) { parameters[key].set(value); }

    // Gets a parameter's value.
    template <typename T> T get(const std::string & key) const
    {
        assert_contains(key);
        return parameters.at(key).getValue<T>();
    }

    // Returns the list of parameter names.
    std::set<std::string> getParameterNames() const
    {
        std::set<std::string> output;
        for (const auto & item : parameters)
            output.insert(item.first);
        return output;
    }

    // Returns true if a parameter appears in the collection.
    bool contains(const std::string & candidate) const
    {
        const auto & names = getParameterNames();
        return names.find(candidate) != names.end();
    }

    // Throws an `invalid_parameter_error` if a parameter does not exist in the collection.
    void assert_contains(const std::string & param) const
    {
        if (not contains(param))
            throw invalid_parameter_error(param);
    }

    // Returns true if a parameter is "allowed".
    // This is usefull in the context of file reading where one wants to read parameters
    // and check if the syntax is correct.
    // This is an alias for `contains`.
    bool isAllowedParameter(const std::string & candidate) { return contains(candidate); }

    void dump() const
    {
        for (const auto & it : parameters)
        {
            std::string key = it.first;
            std::string value = it.second.getValue<std::string>();
            if (value.empty())
                value = "\"\"";
            std::cout << key << " = " << value << std::endl;
        }
    }
};

class ScalableParameterCollection : public ParameterCollection
{
  public:
    ScalableParameterCollection(const std::string & name, const std::string & help, const std::string & value,
                                const std::string scale = "1.0")
        : ParameterCollection(name, help, false, true)
    {
        insert(Parameter(name, value));
    }
};

class SwitchableParameterCollection : public ParameterCollection
{
  public:
    SwitchableParameterCollection(const std::string & name, const std::string & help, const std::string & value,
                                  bool enabled = false)
        : ParameterCollection(name, help, true, false)
    {
        insert(Parameter(name, value));
        if (enabled)
            parameters[switchName(name)].setDefault("true");
    }
};

// Energy parameters.
// Energies are scalable, can be enabled/disabled and optionally have a cutoff parameter.
class EnergyParameterCollection : public ParameterCollection
{
  public:
    EnergyParameterCollection(const std::string & name, const std::string & help, const std::string & cutoff = "",
                              const std::string & scale = "1.0")
        : ParameterCollection(name, help, true, true)
    {
        if (not cutoff.empty())
            insert(CutoffParameter(name, cutoff));
        parameters[scaleName(name)].setDefault(scale);
    }
};

class TrajectoryParameterCollection : public ParameterCollection
{
  public:
    TrajectoryParameterCollection(const std::string & name, const std::string & help, const std::string & path)
        : ParameterCollection(name, help, true, false)
    {
        insert(FrequencyParameter(name, "100"));
        insert(PathParameter(name, path));
    }
};

// Grid parameters:
//   - switchable
//   - optionally scalable
//   - has a path
class GridParameterCollection : public ParameterCollection
{
  public:
    GridParameterCollection(const std::string & name, const std::string & help, const std::string & path = "",
                            bool scalable = false)
        : ParameterCollection(name, help, true, scalable)
    {
        insert(PathParameter(name, path));
    }
};

// Base class for storing MS parameters.
// Basically a ParameterCollection with sections for prettier output.
class MSParametersBase : public ParameterCollection
{
  public:
    MSParametersBase() : ParameterCollection("", ""), _sections() {}

    void insert(const ParameterCollection & col)
    {
        ParameterCollection::insert(col);
        _sections.push_back(col); // !!! WARNING: _sections contains copies of the actual parameters
    }

    void dump() const
    {
        // !!! Parameters stored in `_sections` are copies.
        // !!! Therefore get the help string from the `_sections`
        // !!! then go look for the actual value in `parameters` map.
        for (const auto & col : _sections)
        {
            std::cout << "# == " << col.help << " ==" << std::endl;
            for (const auto & item : col.parameters)
            {
                this->at(item.first).dump();
            }
            std::cout << std::endl;
        }
    }

  protected:
    std::vector<ParameterCollection> _sections;
};

} // namespace MSParameter
} // namespace biospring

#endif // __MSPARAMETER_H__