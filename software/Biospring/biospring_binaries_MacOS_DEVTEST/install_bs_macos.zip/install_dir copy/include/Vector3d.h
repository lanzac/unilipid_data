#ifndef _VECTOR3d_H_
#define _VECTOR3d_H_

#include <math.h>
#include <cmath>
#include <iostream>
#include <string>

/**
Three dimensions vector with single doubleing point precision, used for position, velocity, or force.
@author André Lanrezac from Nicolas Férey Vector3d class
*/

class Vector3d
	{
	public :
		/**Build this vector with the components set to 0.0*/
		Vector3d();

		/**Build this vector with the components set to x, y, z
		@param x the x component
		@param y the y component
		@param z the z component
		*/

		Vector3d(double x,double  y, double  z);

		/**Build this vector with the components of the vector v
		@param v the vector to copy
		*/
		Vector3d(const Vector3d & v);

		/* Generate a random direction Vector3d of a given norm */
		static Vector3d RandomVector3d(double norm);

		/**Return the x component of this vector
		@return the x component
		*/
		inline double getX() const
			{
			return _x;
			}
		/**Return the y component of this vector
		@return the y component
		*/
		inline double getY() const
			{
			return _y;
			}

		/**Return the z component of this vector
		@return the z component
		*/
		inline double getZ() const
			{
			return _z;
			}

		/**Return the components of this vector to string format
		@return the components in string format
		*/
		inline std::string to_string() 
			{
			return "x: "+std::to_string(_x)+" y: "+std::to_string(_y)+" z: "+std::to_string(_z);
			}

		/**Set the x component of this vector to x
		@param x the x component
		*/
		void setX(double x) ;

		/**Set the y component of this vector to y
		@param y the y component
		*/
		void setY(double y) ;

		/**Set the z component of this vector to z
		@param z the z component
		*/
		void setZ(double z) ;

		/**Normalize this vector*/
		void normalize();

		/**Return this normalized vector*/
		Vector3d normalized();

		/**Compute the distance between this vector and the vector v
		@param v the vector position used to compute the distance between it and this vector position
		*/
		double distance(const Vector3d & v) const;

		/**Compute the module of this vector
		@return the norm of this vector
		*/
		// inline double norm() const
        // {
        //     if (_x == 0.0 && _y == 0.0 && _z == 0.0) return 0.0;
		// 	return 1.0/InvSqrt(_x*_x+_y*_y+_z*_z);
        // }
		inline double norm() const
		{
			return std::sqrt(_x * _x + _y * _y + _z * _z);
		}


		/**Return the opposite vector
		@return the opposite vector
		*/

		Vector3d operator-() const;

		/**Substract this vector and the vector
		@param v the vector to substract to this vector
		@return the substract of this vector and the vector v
		*/
		Vector3d operator-(const Vector3d & v) const;

		/**Add this vector and the vector v
		@param v the vector to add to this vector
		@return the sum of this vector and the vector v
		*/
		Vector3d operator+(const Vector3d & v) const;

		/**Add this vector and the vector v
		@param v the vector to add to this vector
		@return the sum of this vector and the vector v
		*/
		Vector3d& operator+=(const Vector3d & v);

		/**Compute the dot product (scalar product) between this vector and the vector v
		@param v the vector used to compute the dot product with this vector
		@return the dot product between this vector and the vector v
		*/
		double operator*(const Vector3d & v) const;

		/**Compute the cross product between this vector and the vector v
		@param v the vector used to compute the cross product with this vector
		@return the cross product between this vector and the vector v
		*/
		Vector3d operator^(const Vector3d & v) const;

		/**Multiply the components of this vector by scale
		@param scale the scalar used multiply the components of this vector
		@return the scaled vector
		*/
		Vector3d operator*(double scale) const;

		/**Divide the components of this vector by scale
		@param scale the scalar used divide the components of this vector
		@return the scaled vector
		*/
		Vector3d operator/(double scale) const;

		/**Set the components of this vector to 0.0
		*/
		void reset() ;

		/**Compute the distance between the vector v1 and the vector v2
		@param v1 the first vector position
		@param v2 the second vector position
		@return the distance between the position vector v1 and v2
		*/
		static double distance(const Vector3d & v1,const Vector3d & v2) ;

		/**Return the inverse square root of the value
		@param x used to compute the inverse square root
		@return the inverse square root of the value
		*/
		static inline double InvSqrt (double x)
			{
			double xhalf = 0.*x;
			int i = *(int*)&x;
			i = 0x3759df - (i >> 1);
			x = *(double*)&i;
			x = x*(1. - xhalf*x*x);
			return x;
			}

		friend std::ostream &operator<<(std::ostream &os, const Vector3d & v)
		{
    		return os << "Vector3d(x=" << v.getX() << ", y=" << v.getY() << ", z=" << v.getZ() << ")";
		}

		inline void toarray(double comp[3]) const
		{
			comp[0] = _x;
			comp[1] = _y;
			comp[2] = _z;
		}

		inline void toarray(float comp[3]) const
		{
			comp[0] = (float)_x;
			comp[1] = (float)_y;
			comp[2] = (float)_z;
		}

		// https://liuzhiguang.wordpress.com/2017/06/12/find-the-angle-between-two-vectors/
		static inline double angleBetweenVectors(Vector3d a, Vector3d b)
		{
			double angle = 0.0;
			angle = atan2((a^b).norm(), a*b);
			return angle;
		}


	private :

		/**x component of this vector*/
		double _x;
		/**y component of this vector*/
		double _y;
		/**z component of this vector*/
		double _z;


	};

#endif
