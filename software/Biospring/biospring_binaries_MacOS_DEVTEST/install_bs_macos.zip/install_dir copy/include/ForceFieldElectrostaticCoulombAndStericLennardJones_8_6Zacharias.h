#ifndef _FORCEFIELDELECTROSTATICCOULOMBANDSTERICLENNARDJONES_8_6_ZACHARIAS_H_
#define _FORCEFIELDELECTROSTATICCOULOMBANDSTERICLENNARDJONES_8_6_ZACHARIAS_H_

#include "ForceField.h" 

class ForceFieldElectrostaticCoulombAndStericLennardJones_8_6Zacharias: public ForceField
	{
	public : 
		

		ForceFieldElectrostaticCoulombAndStericLennardJones_8_6Zacharias();
		virtual ~ForceFieldElectrostaticCoulombAndStericLennardJones_8_6Zacharias();
		virtual double computeStericForceModule(double radius1, double radius2, double epsilon1, double epsilon2,double distance) ; 

		virtual double computeStericEnergy(double radius1, double radius2, double epsilon1, double epsilon2,double distance) ; 


	
		

	};

#endif
