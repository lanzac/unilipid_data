#ifndef _PQRReduceReader_H_
#define _PQRReduceReader_H_

#include <string>

#include "IO/PQRReader.h"
#include "Particle.h"
#include "SpringNetwork.h"

class ParticleGroup;
class Reduce;
class ReduceRule;

class PQRReduceReader : public PQRReader
{
  public:
    PQRReduceReader() : PQRReader(), _reduce(0), _forcefield(0) {}
    PQRReduceReader(const std::string & path) : PQRReduceReader() { _filename = path; }
    PQRReduceReader(const char * const path) : PQRReduceReader() { _filename = path; }

    virtual ~PQRReduceReader() {}

    void read();

    ForceField * getForceField() const { return _forcefield; }
    void setForceField(ForceField * ff) { _forcefield = ff; }

    Reduce * getReduce() const { return _reduce; }
    void setReduce(Reduce * red) { _reduce = red; }

  protected:
  private:
    Reduce * _reduce;
    ForceField * _forcefield;

    void ReduceAminoAcidToGroup(vector<Particle *> & groupbyaa, const string & resname, unsigned resid);
};

#endif
