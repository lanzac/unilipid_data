#ifndef _PDBReduceReader_H_
#define _PDBReduceReader_H_

#include "IO/PDBReader.h"
#include "Particle.h"
#include "Reduce.h"
#include "SpringNetwork.h"

class ParticleGroup;
class Reduce;
class ReduceRule;

class PDBReduceReader : public PDBReader
{
  public:
    PDBReduceReader() : PDBReader(), _reduce(0), _forcefield(0) {}
    PDBReduceReader(const std::string & path) : PDBReduceReader() { _filename = path; }
    PDBReduceReader(const char * const path) : PDBReduceReader() { _filename = path; }

    void read();

    ForceField * getForceField() const { return _forcefield; };
    void setForceField(ForceField * ff) { _forcefield = ff; }

    Reduce * getReduce() const { return _reduce; }
    void setReduce(Reduce * red) { _reduce = red; }

  protected:
  private:
    Reduce * _reduce;
    ForceField * _forcefield;
    void ReduceAminoAcidToGroup(vector<Particle *> & groupbyaa, const string & resname, unsigned resid);
};

#endif
