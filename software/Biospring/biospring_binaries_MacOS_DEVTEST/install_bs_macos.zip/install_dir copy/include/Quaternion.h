#ifndef __QUATERNION_H__
#define __QUATERNION_H__

#include <Vector3d.h>
#include <cmath>
#include <iostream>
#include "matrix.h"

class Quaternion
{
  public:
    // Quaternion(double x, double y, double z, double w) : _x(x), _y(y), _z(z), _w(w) { normalize(); }
    Quaternion(double x, double y, double z, double w) : _x(x), _y(y), _z(z), _w(w) {  }

    Quaternion() : Quaternion(0.0, 0.0, 0.0, 0.0) {}

    // Quaternion(const Quaternion & v) : _x(v._x), _y(v._y), _z(v._z), _w(v._w) { normalize(); }
    Quaternion(const Quaternion & v) : _x(v._x), _y(v._y), _z(v._z), _w(v._w) {  }

    // Quaternion(Vector3d v, double w) : _x(v.getX()), _y(v.getY()), _z(v.getZ()), _w(w) { normalize(); }
    Quaternion(Vector3d v, double w) : _x(v.getX()), _y(v.getY()), _z(v.getZ()), _w(w) {  }

    void setX(double x) { _x = x; }
    double getX() const { return _x; }

    void setY(double y) { _y = y; }
    double getY() const { return _y; }

    void setZ(double z) { _z = z; }
    double getZ() const { return _z; }

    void setW(double w) { _w = w; }
    double getW() const { return _w; }

    Vector3d getV() const { return Vector3d(_x, _y, _z); }

    /**Return the components of this quaternion to string format
		@return the components in string format
		*/
		inline std::string to_string() 
    {
    return "x: "+std::to_string(_x)+" y: "+std::to_string(_y)+" z: "+std::to_string(_z)+" w: "+std::to_string(_w);
    }

    inline int sign() const { return (_w >= 0) ? 1 : -1; }


    double norm() const { return std::sqrt(_w * _w + _x * _x + _y * _y + _z * _z); }

    Quaternion conjugate() const { return Quaternion(-_x, -_y, -_z, _w); }

    Quaternion inverse() const;

    Quaternion rotateVectorAboutAxisAndAngle(Vector3d axis, double angle) const;

    void normalize();

    void fromAxisAngle(double x, double y, double z, double angle);
    void fromAxisAngle(Vector3d & axis, double angle) { fromAxisAngle(axis.getX(), axis.getY(), axis.getZ(), angle); }

    void toAxisAngle(Vector3d * axis, double * angle) const;

    void fromEuler(double ax, double ay, double az);

    Quaternion operator*(const Quaternion & v) const;
    Quaternion operator+(const Quaternion & v) const;
    Quaternion& operator+=(const Quaternion & v);
    Quaternion operator*(double d) const;
    void rotationUsing2Vectors(Vector3d & v1, Vector3d & v2);

    Matrix quaternionToRotationMatrix() const;
    Matrix quaternionToMatrix() const;

  private:
    double _x;
    double _y;
    double _z;
    double _w;
};

#endif // __QUATERNION_H__
