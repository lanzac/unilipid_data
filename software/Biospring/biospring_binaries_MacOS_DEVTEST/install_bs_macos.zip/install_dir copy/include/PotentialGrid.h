#ifndef __POTENTIALGRID_H__
#define __POTENTIALGRID_H__

#include "GridBase.h"
#include "Vector3d.h"

#include <utility>
#include <vector>

struct PotentialCell
{
    double scalar;
    Vector3d vector;
};

class PotentialGrid : public GridBase<PotentialCell>
{
  public:
    using GridBase<PotentialCell>::GridBase;

    void setScalar(double scalar, size_t i, size_t j, size_t k) { (*this)(i, j, k).scalar = scalar; }
    double getScalar(size_t i, size_t j, size_t k) const { return (*this)(i, j, k).scalar; }
    double getScalar(double x, double y, double z) const
    {
        size_t i, j, k;
        if (_T.realToDiscrete(x, y, z, &i, &j, &k))
            return getScalar(i, j, k);
        return SCALAR_OUT_OF_GRID;
    }

    void setVector(const Vector3d & v, size_t i, size_t j, size_t k) { (*this)(i, j, k).vector = v; }
    const Vector3d & getVector(size_t i, size_t j, size_t k) const { return (*this)(i, j, k).vector; }
    const Vector3d & getVector(double x, double y, double z) const
    {
        size_t i, j, k;
        if (_T.realToDiscrete(x, y, z, &i, &j, &k))
            return getVector(i, j, k);
        return VECTOR_OUT_OF_GRID;
    }

    void computeGradient();

    void print() const;

  protected:
  private:
    static const double SCALAR_OUT_OF_GRID;
    static const Vector3d VECTOR_OUT_OF_GRID;
};

#endif // __POTENTIALGRID_H__
