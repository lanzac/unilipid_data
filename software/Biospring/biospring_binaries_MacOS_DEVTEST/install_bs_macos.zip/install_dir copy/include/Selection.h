#ifndef __SELECTION_H__
#define __SELECTION_H__

#include "Vector3d.h"

#include <vector>

class SpringNetwork;

class Selection
{
  public:
    Selection(const std::string & name, SpringNetwork * sp)
        : _name(name), _spn(sp), _selections(), _barycentre(0.0, 0.0, 0.0)
    {
    }

    std::string getName() const { return _name; }

    void setSpringNetwork(SpringNetwork * sp) { _spn = sp; }
    SpringNetwork * getSpringNetwork(void) const { return _spn; }

    Vector3d getBarycentre() const { return _barycentre; }

    std::vector<unsigned> getSelectionIds(void) const { return _selections; }

    void addParticle(unsigned id) { _selections.push_back(id); }

    void computeBarycentre();

    void addForce(const Vector3d & force);

  protected:
    std::string _name;
    SpringNetwork * _spn;
    std::vector<unsigned> _selections;
    Vector3d _barycentre;
};

#endif // __SELECTION_H__
