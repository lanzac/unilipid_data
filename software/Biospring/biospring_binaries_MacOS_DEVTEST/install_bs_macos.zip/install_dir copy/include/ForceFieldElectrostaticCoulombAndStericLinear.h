#ifndef _FORCEFIELDELECTROSTATICCOULOMBANDSTERICLINEAR_H_
#define _FORCEFIELDELECTROSTATICCOULOMBANDSTERICLINEAR_H_

#include "ForceField.h" 

class ForceFieldElectrostaticCoulombAndStericLinear: public ForceField
	{
	public : 
		

		ForceFieldElectrostaticCoulombAndStericLinear();
		virtual ~ForceFieldElectrostaticCoulombAndStericLinear();
		virtual double computeStericForceModule(double radius1, double radius2, double epsilon1, double epsilon2,double distance) ; 

		virtual double computeStericEnergy(double radius1, double radius2, double epsilon1, double epsilon2,double distance) ; 


	};

#endif
