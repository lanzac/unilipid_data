
#ifndef __ARGPARSE__H__
#define __ARGPARSE__H__

#include <iostream>
#include <string>
#include <vector>

#include "logging.h"
#include "utils.h"

namespace biospring
{
namespace argparse
{

class CommandLineArgumentsBase
{
  public:
    std::vector<std::string> args;

    // Program's description.
    std::vector<std::string> description;
    std::string getDescriptionString() const { return String::join(description, "\n"); }
    void printUsage() const { std::cerr << getDescriptionString() << std::endl; }

    // Constructor with default value for command line parameters.
    CommandLineArgumentsBase() : args() {}
    CommandLineArgumentsBase(int argc, const char * const argv[]);
    CommandLineArgumentsBase(const std::vector<std::string> & arguments): args(arguments) {};

    virtual void printArgumentValue() const = 0;
    virtual void parseCommandLine() = 0;

    void checkHelpRequired() const;

    void checkNextArg(const size_t argi, std::string & value);

    template <typename T> inline void parseNextArg(size_t & argi, T & value);

  protected:

  private:
};



template <typename T> inline void CommandLineArgumentsBase::parseNextArg(size_t & argi, T & value)
{
    std::string buf;
    checkNextArg(argi, buf);
    bool success = String::from_string(value, buf);
    if (not success)
    {
        logging::die("Invalid double value '%s' for argument '%s'", buf.c_str(), args[argi].c_str());
    }
    argi++;
}

// Parses string value associated with current argument.
template <> inline void CommandLineArgumentsBase::parseNextArg(size_t & argi, std::string & value)
{
    checkNextArg(argi, value);
    argi++;
}

void printUsage(size_t ndesc, const char ** desc);
void printUsage(std::vector<std::string> desc);

} // namespace argparse

} // namespace biospring

#endif