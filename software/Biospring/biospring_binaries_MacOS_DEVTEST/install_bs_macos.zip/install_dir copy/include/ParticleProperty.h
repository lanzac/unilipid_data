#ifndef __PARTICLEPROPERTY_H__
#define __PARTICLEPROPERTY_H__

class ParticleProperty
{
  public:
    ParticleProperty()
        : _mass(1.0), _charge(0.0), _electroncharge(0), _radius(1.0), _epsilon(0.0), _tempfactor(0.0), _occupancy(0.0),
          _solventaccessibilitysurface(0.0), _transferenergybyaccessiblesurface(0.0), _ischarged(false), _burying(1.0)
    {
    }

    void setCharge(double charge);
    double getCharge() const { return _charge; }

    void setElectronCharge(int charge);
    int getElectronCharge() const { return _electroncharge; }

    bool isCharged() const { return _ischarged; }

    void setRadius(double radius) { _radius = radius; }
    double getRadius() const { return _radius; }

    void setMass(double mass) { _mass = mass; }
    double getMass() const { return _mass; }

    double getTempFactor() const { return _tempfactor; }
    void setTempFactor(double temp) { _tempfactor = temp; }

    double getOccupancy() const { return _occupancy; }
    void setOccupancy(double occupancy) { _occupancy = occupancy; }

    double getEpsilon() const { return _epsilon; }
    void setEpsilon(double epsilon) { _epsilon = epsilon; }

    double getHydrophobicity() const { return _hydrophobicity; }
    void setHydrophobicity(double hydrophobicity);
    bool isHydrophobic() const { return _ishydrophobic; }

    double getSolventAccessibilitySurface() const { return _solventaccessibilitysurface; }
    void setSolventAccessibilitySurface(double sas) { _solventaccessibilitysurface = sas; }

    double getTransferEnergyByAccessibleSurface() const { return _transferenergybyaccessiblesurface; }
    void setTransferEnergyByAccessibleSurface(double transferenergybyaccessiblesurface);

    double getBurying() const { return _burying; }
    void setBurying(double burying) { _burying = burying; }

  protected:
  private:
    double _mass;
    double _charge;
    int _electroncharge;
    double _radius;
    double _epsilon;
    double _tempfactor;
    double _occupancy;
    double _hydrophobicity;
    double _solventaccessibilitysurface;
    double _transferenergybyaccessiblesurface;
    bool _ischarged;
    bool _ishydrophobic;
    double _burying;
};

#endif // __PARTICLEPROPERTY_H__
