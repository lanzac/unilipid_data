#ifndef __PARTICLE_H__
#define __PARTICLE_H__

#include "Cell.h"
#include "ForceField.h"
#include "ParticleProperty.h"
#include "SpringNetwork.h"
#include "Vector3d.h"
#include "Vector3d.h"

class Spring;

class Particle : public ParticleProperty
{
  public:
    Particle()
        : ParticleProperty(), _force(Vector3d()), _savedforce(Vector3d()), _position(Vector3d()), _velocity(Vector3d()), _isstatic(false),
          _isinit(false), _name(""), _resid(0), _resname(""), _chainname(""), _internalstructid(0), _springneighbors(),
          _stericcell(NULL), _electrostaticcell(NULL), _hydrophobiccell(NULL), _extid(-1), _springnetwork(NULL)
    {
    }

    void setSpringNetwork(SpringNetwork * springnetwork) { _springnetwork = springnetwork; }
    SpringNetwork * getSpringNetwork() const { return _springnetwork; }

    void setId(int id) { _id = id; }
    int getId() const { return _id; }

     void setRbId(int rbid) { _rbid = rbid; }
    int getRbId() const { return _rbid; }

    void setExtid(unsigned id) { _extid = id; }
    unsigned getExtid() const { return _extid; }

    bool isDynamic() const { return !isStatic(); }
    void setDynamic(bool isdynamic) { _isstatic = !isdynamic; }

    bool isStatic() const { return _isstatic; }
    bool isInit() const { return _isinit; }

    void setStatic(bool isstatic);
    void setInit(bool isinit);

    void setElectrostaticEnergy(double energy) { _electrostaticenergy = energy; }
    double getElectrostaticEnergy() const { return _electrostaticenergy; }

    void setStericEnergy(double energy) { _stericenergy = energy; }
    double getStericEnergy() const { return _stericenergy; }

    void setKineticEnergy(double energy) { _kineticenergy = energy; }
    double getKineticEnergy() const { return _kineticenergy; }

    void setPreviousPosition(const Vector3d & v) { _previousposition = v; }
    Vector3d getPreviousPosition() const { return _previousposition; }

    void setIMPEnergy(double energy) { _impenergy = energy; }
    double getIMPEnergy() const { return _impenergy; };

    void setHydrophobicityEnergy(double energy) { _hydrophobicityenergy = energy; }
    double getHydrophobicityEnergy() const { return _hydrophobicityenergy; }

    void setPosition(const Vector3d & v);
    Vector3d getPosition() const { return _position; }

    void setForce(const Vector3d & v) { _force = v; }
    Vector3d getForce() const { return _force; }
    void addForce(const Vector3d & v) { _force = _force + v; }
    void saveForce() { _savedforce = _force;}
    Vector3d getSavedForce() const { return _savedforce;}

    void setVelocity(const Vector3d & v) { _velocity = v; }
    Vector3d getVelocity() const { return _velocity; }
    void addVelocity(const Vector3d & v) { _velocity = _velocity + v; }

    void setNearestMembraneVertexPosition(const Vector3d & v) { _nearestmembvertex = v; }
    Vector3d getNearestMembraneVertexPosition() const { return _nearestmembvertex; }

    double distance(const Particle & p) const { return _position.distance(p.getPosition()); }
    static double distance(const Particle & p1, const Particle & p2)
    {
        return Vector3d::distance(p1.getPosition(), p2.getPosition());
    }

    double getX() const { return _position.getX(); }
    double getY() const { return _position.getY(); }
    double getZ() const { return _position.getZ(); }

    void setX(double x) { _position.setX(x); }
    void setY(double y) { _position.setY(y); }
    void setZ(double z) { _position.setZ(z); }

    unsigned getResId() const { return _resid; }
    void setResId(unsigned resid) { _resid = resid; }

    const std::string & getResName() const { return _resname; }
    void setResName(const std::string & resname) { _resname = resname; }

    const std::string & getName() const { return _name; }
    void setName(const std::string & name) { _name = name; }

    const std::string & getCGName() const { return _cgname; }
    void setCGName(const std::string & cgname) { _cgname = cgname; }

    const std::string & getChainName() const { return _chainname; }
    void setChainName(const std::string & chainname) { _chainname = chainname; }

    const std::string & getElementName() const { return _elementname; }
    void setElementName(const std::string & elementname) { _elementname = elementname; }

    // _elementname set to empty string after reducer !
    // Maybe we should add element name information in reduce file / ReduceRuleReader
    //bool isCA() const { return (_name.find("CA") != std::string::npos) && (_elementname == "C"); }
    bool isCA() const { return (_name.find("CA") != std::string::npos); }

    void removeSpringNeighbor(unsigned index) { _springneighbors.erase(index); }
    void addToSpringNeighbors(unsigned index, Spring * spring);

    unsigned getNumberOfSprings() const { return _springneighbors.size(); }

    bool isInSpringNeighbors(unsigned index) { return _springneighbors.find(index) != _springneighbors.end(); }

    void setStericCell(Cell * cell) { _stericcell = cell; }
    Cell * getStericCell() const { return _stericcell; }

    void setElectrostaticCell(Cell * cell) { _electrostaticcell = cell; }
    Cell * getElectrostaticCell() const { return _electrostaticcell; }

    void setHydrophobicCell(Cell * cell) { _hydrophobiccell = cell; }
    Cell * getHydrophobicCell() const { return _hydrophobiccell; }

    void addElectrostaticFieldForce();
    void addDensityFieldForce();
    void addElectrostaticForceNoGrid(double cutoff);
    void addElectrostaticForce();
    void addStericForce();
    void addIMPForce();
    void addHydrophobicityForce();
    void addElectrostaticFieldProbeForce(Particle * probe);
    void addElectrostaticProbeForce(Particle * probe);
    void addStericProbeForce(Particle * probe);

    void MoveInGrid();

    void resetForce();

    void applyViscosity(double viscosity);

    void computeStericNeighbors();
    void computeElectrostaticNeighbors();
    void computeHydrophobicNeighbors();

    void moveInElectrostaticGrid();
    void moveInStericGrid();
    void moveInHydrophobicGrid();

    void addInElectrostaticGrid();
    void addInStericGrid();
    void addInHydrophobicGrid();

    void addInSpringGrid();

    void updateFromForceField(ForceField * ff);
    void IntegrateVelocityVerlet(double timestep);
    void IntegrateEuler(double timestep);

    inline void clearSpringNeighbors() { _springneighbors.clear(); }

    inline unsigned getInternalStructId() const { return _internalstructid; }
    inline void setInternalStructId(const unsigned structid) { _internalstructid = structid; }

    std::string tostr() const;

  private:
    void _integrateForce(double timestep);
    void _integrateVelocity(double timestep);

    Vector3d _force;
    Vector3d _savedforce;
    Vector3d _position;
    Vector3d _previousposition;
    Vector3d _velocity;
    Vector3d _nearestmembvertex;
    bool _isstatic;
    bool _isinit;

    std::string _name;   // name in pdb
    std::string _cgname; // coarse grain name in pdb
    unsigned _resid;
    std::string _resname;
    std::string _chainname;
    std::string _elementname;
    unsigned _internalstructid;

    unordered_map<unsigned, Spring *> _springneighbors;

    Cell * _stericcell;
    Cell * _electrostaticcell;
    Cell * _springcell;
    Cell * _hydrophobiccell;

    double _kineticenergy;
    double _electrostaticenergy;
    double _stericenergy;
    double _impenergy;
    double _hydrophobicityenergy;

    unsigned _extid;
    int _id;
    int _rbid; // Rigid body id
    SpringNetwork * _springnetwork;
};

#endif // __PARTICLE_H__
