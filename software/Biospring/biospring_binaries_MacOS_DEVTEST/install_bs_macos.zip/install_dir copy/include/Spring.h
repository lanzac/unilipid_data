#ifndef __SPRING_H__
#define __SPRING_H__

#include "ForceField.h"
#include "Particle.h"

class Spring
{
  public:
    static const double DEFAULT_EQUILIBRIUM;
    static const double DEFAULT_STIFFNESS;

    Spring(Particle * p1, Particle * p2, double equilibrium, double stiffness, ForceField * ff)
        : _p1(p1), _p2(p2), _equilibrium(equilibrium), _stiffness(stiffness), _length(0.0), _energy(0.0), _ff(ff)
    {
        computeLength();
    }

    Spring(Particle * p1, Particle * p2, ForceField * ff) : Spring(p1, p2, DEFAULT_EQUILIBRIUM, DEFAULT_STIFFNESS, ff) {}

    Spring(Particle * p1, Particle * p2, double equilibrium, ForceField * ff) : Spring(p1, p2, equilibrium, DEFAULT_STIFFNESS, ff) {}

    void setParticle1(Particle * p1) { _p1 = p1; }
    Particle * getParticle1() const { return _p1; }

    void setParticle2(Particle * p2) { _p2 = p2; }
    Particle * getParticle2() const { return _p2; }

    void setStiffness(double stiffness) { _stiffness = stiffness; }
    double getStiffness() const { return _stiffness; }

    void setEquilibrium(double equilibrium) { _equilibrium = equilibrium; }
    double getEquilibrium() const { return _equilibrium; }

    double getLength() const { return _length; }

    double getEnergy() const { return _energy; }

    void setForceField(ForceField * ff) { _ff = ff; }
    ForceField * getForceField() const { return _ff; }

    void computeEnergy();
    void computeLength();

    Spring * getOppositeSpring() const { return new Spring(_p2, _p1, _ff); }

    void applyForceToParticle();

  private:
    Particle * _p1;
    Particle * _p2;
    double _equilibrium;
    double _stiffness;
    double _length;
    double _energy;
    ForceField * _ff;
};

#endif // __SPRING_H__
