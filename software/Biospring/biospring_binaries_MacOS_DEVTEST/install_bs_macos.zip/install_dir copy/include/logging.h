

#ifndef __BIOSPRING_LOGGING_H__
#define __BIOSPRING_LOGGING_H__

#include <cstdlib>

#define asize(a) (sizeof(a) / sizeof((a)[0]))

namespace biospring
{

namespace logging

{

void debug(const char * fmt, ...);
void die(const char * fmt, ...);
void error(const char * fmt, ...);
void info(const char * fmt, ...);
void status(const char * fmt, ...);
void warning(const char * fmt, ...);

} // namespace logging

} // namespace biospring

#endif // __BIOSPRING_LOGGING_H__
