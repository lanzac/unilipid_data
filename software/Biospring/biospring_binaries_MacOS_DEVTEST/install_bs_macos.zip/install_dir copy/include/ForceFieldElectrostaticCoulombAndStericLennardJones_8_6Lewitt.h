#ifndef _FORCEFIELDELECTROSTATICCOULOMBANDSTERICLENNARDJONES_8_6_LEWITT_H_
#define _FORCEFIELDELECTROSTATICCOULOMBANDSTERICLENNARDJONES_8_6_LEWITT_H_

#include "ForceField.h" 

class ForceFieldElectrostaticCoulombAndStericLennardJones_8_6Lewitt: public ForceField
	{
	public : 
		

		ForceFieldElectrostaticCoulombAndStericLennardJones_8_6Lewitt();
		virtual ~ForceFieldElectrostaticCoulombAndStericLennardJones_8_6Lewitt();
		virtual double computeStericForceModule(double radius1, double radius2, double epsilon1, double epsilon2,double distance) ; 

		virtual double computeStericEnergy(double radius1, double radius2, double epsilon1, double epsilon2,double distance) ; 


	
		

	};

#endif
