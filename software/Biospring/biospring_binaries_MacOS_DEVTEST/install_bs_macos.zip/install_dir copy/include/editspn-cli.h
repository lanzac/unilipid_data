

#include <string>
#include <unordered_map>
#include <vector>

#include "argparse.h"
#include "SpringNetwork.h"

namespace biospring
{

namespace editspn
{

//
// Stores a spring descriptors:
//   - p1: first particle string representation (see Particle::tostr())
//   - p2: second particle string representation (see Particle::tostr())
//   - stiffness: spring stiffness
//   - equilibrium: distance between the two particules where the spring is at equilibrium
//
struct SpringDescriptor
{
    std::string p1;
    std::string p2;
    double stiffness;
    double equilibrium;
};

//
// Handles command-line parsing as well as argument storage.
//
class CommandLineArguments : public biospring::argparse::CommandLineArgumentsBase
{
  public:
    // I/O paths.
    std::string pathTopology;
    std::vector<std::string> pathOutputList;
    std::string pathUpdateSprings;

    // User options.
    double cutoff;    // cutoff value for spring creation
    double stiffness; // stiffness for spring creation

    // Constructor with default value for command line parameters.
    CommandLineArguments();
    void printArgumentValue() const;
    void parseCommandLine();

    // Access to private flags.
    bool isUserOutput() const { return _isUserOutput; }
    bool isUserCutoff() const { return _isUserCutoff; }
    bool isUserStiffness() const { return _isUserStiffness; }

    void setUserOutput(bool b) { _isUserOutput = b; }
    void setUserCutoff(bool b) { _isUserCutoff = b; }
    void setUserStiffness(bool b) { _isUserStiffness = b; }

    void useUserOutput() { setUserOutput(true); }
    void useUserCutoff() { setUserCutoff(true); }
    void useUserStiffness() { setUserStiffness(true); }


  private:
    // Internal parameters;
    bool _isUserOutput;    // flag indicating whether the -o, --output option has been used
    bool _isUserCutoff;    // flag indicating whether the -c, --cutoff option has been used
    bool _isUserStiffness; // flag indicating whether the -d, --stiffness option has been used
};

void readSpringFile(const std::string & filename, std::vector<SpringDescriptor> & sdesc);
void addSpringsToSpn(const std::vector<SpringDescriptor> & sdesc, SpringNetwork & spn);
void addSpringsToSpn(const std::string & path, SpringNetwork & spn);

void checkParticleIdFormat(const std::string & pid, const unsigned & lineid);
void checkParticleInSpn(const std::string & pid, const std::unordered_map<std::string, unsigned> & pidmap);

int main(int argc, char ** argv);

} // namespace editspn
} // namespace biospring
