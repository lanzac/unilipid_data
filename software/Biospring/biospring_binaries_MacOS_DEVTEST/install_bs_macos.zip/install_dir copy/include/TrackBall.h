#ifndef _TRACKBALL_H_
#define _TRACKBALL_H_

#include "Vector3d.h"
#include "Quaternion.h"


class TrackBall
	{
	public : 

		TrackBall(unsigned witdh, unsigned height, double radius);
				
		Quaternion getRotation() const;
		void mouseClic(unsigned x,unsigned y);
		void mouseDrag(unsigned x, unsigned y);
	private : 

		Quaternion _rotation;
		unsigned _width;
		unsigned _height;
		double _radius;
		Vector3d _newspherepoint;
		Vector3d _lastspherepoint;		
		
		Vector3d computeTrackBallPoint(double x, double y) const;
		
		
	};

#endif
