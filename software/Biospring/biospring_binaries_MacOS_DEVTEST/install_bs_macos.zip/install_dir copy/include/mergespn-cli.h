
#include "SpringNetwork.h"
#include "argparse.h"

#include <string>
#include <vector>

namespace biospring
{

namespace mergespncli
{

//
// Handles command-line parsing as well as argument storage for program mergespn.
//
class CommandLineArguments : public biospring::argparse::CommandLineArgumentsBase
{
  public:
    // I/O paths.
    std::vector<std::string> pathTopologyList;
    std::vector<std::string> pathOutputList;

    // User options.
    double cutoff;

    // Constructor with default value for command line parameters.
    CommandLineArguments(int argc, const char * const argv[]);
    CommandLineArguments() : CommandLineArguments(0, nullptr){};

    // Implements abstract methods from parent class.
    void printArgumentValue() const;
    void parseCommandLine();

    // Access to private flags.
    void setUserOutput(bool b) { _isUserOutput = b; }
    bool isUserOutput() const { return _isUserOutput; }
    void useUserOutput() { setUserOutput(true); }

    void setUserCutoff(bool b) { _isUserCutoff = b; }
    bool isUserCutoff() const { return _isUserCutoff; }
    void useUserCutoff() { setUserCutoff(true); }

  protected:
    // Internal parameters;
    bool _isUserOutput; // flag indicating whether the -o, --output option has been used
    bool _isUserCutoff; // flag indicating whether the -c, --cutoff option has been used
};

int main(int argc, char ** argv);

} // namespace mergespncli

} // namespace biospring
