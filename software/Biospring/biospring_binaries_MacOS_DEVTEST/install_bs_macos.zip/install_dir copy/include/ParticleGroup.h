#ifndef _GROUP_H_
#define _GROUP_H_

#include <string>
#include <vector>

#include "ForceField.h"
#include "Particle.h"

using namespace std;

class ParticleGroup : public Particle
{
  public:
    ParticleGroup() : _group(), _ff(nullptr) {}

    void addParticle(const Particle * p);
    void print();
    void reduce(ForceField * ff);

    size_t size(void) const { return _group.size(); }

    const Particle * getParticleOfGroupFromIndex(unsigned i) { return _group[i]; }

    bool contains(const std::string & name) const;
    bool contains(const Particle & p) const;

  private:
    vector<const Particle *> _group;
    ForceField * _ff;

    void _updatePositionWithMassCenter();
};

#endif
