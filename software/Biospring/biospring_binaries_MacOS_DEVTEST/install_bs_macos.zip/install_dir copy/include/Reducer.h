
//
// Defines the reducer class which reduces an all atom topology
// to a coarse grain topology.
//

#ifndef __REDUCER_H__
#define __REDUCER_H__

#include <string>
#include <vector>

#include "ForceField.h"
#include "Particle.h"
#include "Reduce.h"
#include "SpringNetwork.h"

namespace biospring
{

//
// Storage of reduction to coarse grain parameters.
//
// This is used by command-line parsers to store parameters and pass it to
// actual Reducer instance.
//
struct ReductionParameters
{
    std::string pathGroup;
    std::string pathForceField;
    bool ignoreMissing;   // ignore missing particles?
    bool ignoreDuplicate; // ignore duplicate particles?

    ReductionParameters() : pathGroup(""), pathForceField(""), ignoreMissing(false), ignoreDuplicate(false) {}
};

class Reducer
{
  public:
    Reducer() : _spn(0), _reduce(0), _ff(0), _ignoreDuplicateParticles(false), _ignoreMissingParticle(false) {}

    void setIgnoreDuplicateParticles(bool value) { _ignoreDuplicateParticles = value; }
    void ignoreDuplicateParticles() { _ignoreDuplicateParticles = true; }
    bool getIgnoreDuplicateParticles() const { return _ignoreDuplicateParticles; }

    void setIgnoreMissingParticles(bool value) { _ignoreMissingParticle = value; }
    void ignoreMissingParticles() { _ignoreMissingParticle = true; }
    bool getIgnoreMissingParticles() const { return _ignoreMissingParticle; }

    SpringNetwork * getSpringNetwork(void) const { return _spn; }
    void setSpringNetwork(SpringNetwork * const spn) { _spn = spn; }

    Reduce * getReduce(void) const { return _reduce; }
    void setReduce(Reduce * const red) { _reduce = red; }
    void setReduce(const std::string & path);

    ForceField * getForceField(void) const { return _ff; }
    void setForceField(ForceField * const ff) { _ff = ff; }
    void setForceField(const std::string & path);

    void reduce(void) const;
    void reduceToCoarseGrain(SpringNetwork & spn, const ReductionParameters & parameters);

  protected:
    SpringNetwork * _spn;
    Reduce * _reduce;
    ForceField * _ff;

    bool _ignoreDuplicateParticles;
    bool _ignoreMissingParticle;

    void _reduceAA(std::vector<Particle *> & particles, std::vector<Particle *> & cgParticles,
                   const std::string & resname, const size_t resid) const;
};

} // namespace biospring

#endif // __REDUCER_H__
