#ifndef _VECTOR3f_H_
#define _VECTOR3f_H_

#include <math.h>
#include <iostream>
#include <string>

/**
Three dimensions vector with single floating point precision, used for position, velocity, or force.
@author Nicolas Ferey
*/

class Vector3f
	{
	public :
		/**Build this vector with the components set to 0.0*/
		Vector3f();

		/**Build this vector with the components set to x, y, z
		@param x the x component
		@param y the y component
		@param z the z component
		*/

		Vector3f(float x,float  y, float  z);

		/**Build this vector with the components of the vector v
		@param v the vector to copy
		*/
		Vector3f(const Vector3f & v);

		/* Generate a random direction Vector3f of a given norm */
		static Vector3f RandomVector3f(float norm);

		/**Return the x component of this vector
		@return the x component
		*/
		inline float getX() const
			{
			return _x;
			}
		/**Return the y component of this vector
		@return the y component
		*/
		inline float getY() const
			{
			return _y;
			}

		/**Return the z component of this vector
		@return the z component
		*/
		inline float getZ() const
			{
			return _z;
			}

		/**Return the components of this vector to string format
		@return the components in string format
		*/
		inline std::string to_string() 
			{
			return "x: "+std::to_string(_x)+" y: "+std::to_string(_y)+" z: "+std::to_string(_z);
			}

		/**Set the x component of this vector to x
		@param x the x component
		*/
		void setX(float x) ;

		/**Set the y component of this vector to y
		@param y the y component
		*/
		void setY(float y) ;

		/**Set the z component of this vector to z
		@param z the z component
		*/
		void setZ(float z) ;

		/**Normalize this vector*/
		void normalize();

		/**Compute the distance between this vector and the vector v
		@param v the vector position used to compute the distance between it and this vector position
		*/
		float distance(const Vector3f & v) const;

		/**Compute the module of this vector
		@return the norm of this vector
		*/
		inline float norm() const
        {
            if (_x == 0.0 && _y == 0.0 && _z == 0.0) return 0.0;
			return 1.0/InvSqrt(_x*_x+_y*_y+_z*_z);
        }

		/**Return the opposite vector
		@return the opposite vector
		*/

		Vector3f operator-() const;

		/**Substract this vector and the vector
		@param v the vector to substract to this vector
		@return the substract of this vector and the vector v
		*/
		Vector3f operator-(const Vector3f & v) const;

		/**Add this vector and the vector v
		@param v the vector to add to this vector
		@return the sum of this vector and the vector v
		*/
		Vector3f operator+(const Vector3f & v) const;

		/**Add this vector and the vector v
		@param v the vector to add to this vector
		@return the sum of this vector and the vector v
		*/
		Vector3f& operator+=(const Vector3f & v);

		/**Compute the dot product (scalar product) between this vector and the vector v
		@param v the vector used to compute the dot product with this vector
		@return the dot product between this vector and the vector v
		*/
		float operator*(const Vector3f & v) const;

		/**Compute the cross product between this vector and the vector v
		@param v the vector used to compute the cross product with this vector
		@return the cross product between this vector and the vector v
		*/
		Vector3f operator^(const Vector3f & v) const;

		/**Multiply the components of this vector by scale
		@param scale the scalar used multiply the components of this vector
		@return the scaled vector
		*/
		Vector3f operator*(float scale) const;

		/**Divide the components of this vector by scale
		@param scale the scalar used divide the components of this vector
		@return the scaled vector
		*/
		Vector3f operator/(float scale) const;

		/**Set the components of this vector to 0.0
		*/
		void reset() ;

		/**Compute the distance between the vector v1 and the vector v2
		@param v1 the first vector position
		@param v2 the second vector position
		@return the distance between the position vector v1 and v2
		*/
		static float distance(const Vector3f & v1,const Vector3f & v2) ;

		/**Return the inverse square root of the value
		@param x used to compute the inverse square root
		@return the inverse square root of the value
		*/
		static inline float InvSqrt (float x)
			{
			float xhalf = 0.5f*x;
			int i = *(int*)&x;
			i = 0x5f3759df - (i >> 1);
			x = *(float*)&i;
			x = x*(1.5f - xhalf*x*x);
			return x;
			}

		friend std::ostream &operator<<(std::ostream &os, const Vector3f & v)
		{
    		return os << "Vector3f(x=" << v.getX() << ", y=" << v.getY() << ", z=" << v.getZ() << ")";
		}

		inline void toarray(float comp[3]) const
		{
			comp[0] = _x;
			comp[1] = _y;
			comp[2] = _z;
		}

		// https://liuzhiguang.wordpress.com/2017/06/12/find-the-angle-between-two-vectors/
		static inline float angleBetweenVectors(Vector3f a, Vector3f b)
		{
			double angle = 0.0;
			angle = atan2((a^b).norm(), a*b);
			return angle;
		}


	private :

		/**x component of this vector*/
		float _x;
		/**y component of this vector*/
		float _y;
		/**z component of this vector*/
		float _z;


	};

#endif
