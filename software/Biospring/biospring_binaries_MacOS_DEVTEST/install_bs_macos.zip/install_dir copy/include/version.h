
#ifndef __VERSION_H__
#define __VERSION_H__


#include <string>

namespace biospring
{

static const std::string VERSION_STRING = "1.0.1-ec2e330";

} // namespace biospring


#endif // __VERSION_H__
