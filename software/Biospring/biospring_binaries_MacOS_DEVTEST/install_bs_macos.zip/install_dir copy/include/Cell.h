#ifndef __CELL_H__
#define __CELL_H__

#include "Vector3d.h"

#include <unordered_set>
#include <vector>

class Grid;
class Particle;

// Cell (voxel) of a three dimensionnal grid
class Cell
{
  public:
    // Empty constructor.
    Cell() : Cell(0, 0, 0, nullptr) {}

    // Builds a new cell using its indexes and associated grid
    Cell(unsigned i, unsigned j, unsigned k, Grid * grid)
        : _grid(grid), _particules(new std::unordered_set<unsigned>),
          _particuleneighbors(new std::unordered_set<unsigned>), _recomputeparticleneighbors(true), _neighbors(), _i(i),
          _j(j), _k(k), _scalar(0.0), _vector()
    {
    }

    virtual ~Cell() {}

    // Compute the neighbors of this cell
    unsigned computeNeighbors();

    // Returns the ids of the particles in the neighbors of this cell
    inline std::unordered_set<unsigned> * getParticleNeighbors() const { return _particuleneighbors; }

    // Returns the cells in the neighbors of this cell
    inline std::vector<Cell *> getNeighbors() const { return _neighbors; }

    // Returns the ids of the particles in this cell
    inline std::unordered_set<unsigned> * getParticles() const { return _particules; }

    // Gets / Sets the vector (gradient) of this cell computed using the scalar of the neighbors cells
    inline Vector3d getVector() const { return _vector; }
    void setVector(const Vector3d & v) { _vector = v; }

    // Gets / Sets the scalar.
    void setScalar(double scalar) { _scalar = scalar; }
    inline double getScalar() const { return _scalar; }

    // Removes the particle from this cell using its index
    void removeParticle(unsigned index);

    // Adds the particle in this cell usings its index
    void addParticle(unsigned index);

    // Adds the particle in the neighbors of this cell usings its index
    void addParticleInNeighbors(unsigned index);

    // Removes the particle in the neighbors of this cell using its index
    void removeParticleInNeighbors(unsigned index);

    // Clears the particle list and resets vector and scalar.
    void empty();

    // Prints the cell with its indexes and the particles indexes in this cell, and in in its neighbors
    void print() const;

  private:
    Grid * _grid;                                       // The grid to which this cell belongs to
    std::unordered_set<unsigned> * _particules;         // The particles in this cell
    std::unordered_set<unsigned> * _particuleneighbors; // The particles in the neighbors in this cell
    bool _recomputeparticleneighbors;                   // To force to recompute particle neighbors of this cell
    std::vector<Cell *> _neighbors;                     // The neighbors of this cell

    int _i; // x index of this cell
    int _j; // y index of this cell
    int _k; // z index of this cell

    double _scalar;    // The electrostatic potential of this cell
    Vector3d _vector; // The electrostatic gradient of this cell

    // Forces neighbors particle list recomputing
    void setRecomputeParticleNeighbors(bool recompute) { _recomputeparticleneighbors = recompute; }
};

#endif // __CELL_H__
