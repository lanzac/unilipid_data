#The web page of the BioSpring documentation is generated using Markdown.
#The source file of the tutorial is mddriver_markdown.txt.

#To regenerate the html from doc/USERMANUAL file, and integrate 
#this in the doxygen documentation, use this command, BEFORE 
#generating documentation with Doxygen : 

perl Markdown.pl --html4tags ../USERMANUAL > ../html/biospring.html

#It generate mddriver.html which contains the tutorial and put it in
#the parent html directory. 
