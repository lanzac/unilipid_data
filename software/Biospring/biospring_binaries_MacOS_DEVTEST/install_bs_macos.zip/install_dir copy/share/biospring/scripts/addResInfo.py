#!/usr/bin/env python3
import sys
import os
import argparse
import atomium



def addInfo(args):


	# pdb = atomium.open(args.pdb)
	# for r in pdb.model.residues():
	# 	if (r.id in args.res):
	# 		print(r.id)
	# 		for a in r.atoms():
	# 			print(a.occupancy)

	pdbFile = open(args.pdb,"r")
	outFile = open(args.out, "w")
	lines = [line for line in pdbFile.readlines() if line.startswith("ATOM")]
	pdbFile.close()

	res_to_filter = []
	if (args.res):
		res_to_filter = args.res
	elif (args.resfile):
		rf = open(str(args.resfile),"r")
		rfl = [line for line in rf.readlines()]
		for l in rfl:
			if l.startswith("chain:"):
				chain = l.split()[1]
			elif l != "\n":
				if ('-' in l):
					start, end = l.rstrip('\r\n').split('-')
					for i in range(int(start), int(end) + 1):
						res_to_filter.append(chain + '.' + str(i))
				else:
					res_to_filter.append(chain + '.' + l.rstrip('\r\n'))

	for l in lines:
		# atom = l[0:6].strip()
		# atomid = l[6:11].strip()
		# atomname = l[12:16].strip()
		# altloc = l[16:17].strip()
		# resname = l[17:20].strip()
		# chainid = l[21:22].strip()
		# resid = l[22:26].strip()
		# resinsercode = l[26:27].strip() 
		# x = l[30:38].strip()
		# y = l[38:46].strip()
		# z = l[46:54].strip()
		# occupency = l[54:60].strip()
		# tempfactor = l[60:66].strip()
		# elem  = l[76:78].strip()
		# charge = l[78:80].strip()

		chainid = l[21:22]
		resid = l[22:26].strip()
		
		id = chainid + '.' + resid

		# reset occupency and bfactor to 0
		l = "{}{:6.2f}{:6.2f}          {}".format(l[:54], 0, 0, l[76:], end='')

		if (id in res_to_filter):
			# occupency
			l = "{}{:6.2f}{}".format(l[:54], -1, l[60:], end='')
		
		outFile.write("{}\n".format(l))
	outFile.close()

		# print("{:6s}{:5d} {:^4s}{:1s}{:3s} {:1s}{:4d}{:1s}   {:8.3f}{:8.3f}{:8.3f}{:6.2f}{:6.2f}          {:>2s}{:2s}".format(atom,
		# 																													  atomid,
		# 																													  atomname,
		# 																													  altloc,
		# 																													  resname,
		# 																													  chainid,
		# 																													  resid,
		# 																													  resinsercode,
		# 																													  x,
		# 																													  y,
		# 																													  z,
		# 																													  occupency,
		# 																													  tempfactor,
		# 																													  elem,
		# 																													  charge))
	


parser = argparse.ArgumentParser(description="Add some specific additional informations to PDB.")
parser.add_argument('pdb', type=str, help="PDB input file")
parser.add_argument('out', type=str, help="PDB output file")
parser.add_argument('-s','--section', type=str, choices=['occupancy'], help="Data section chosed...")
parser.add_argument('-i','--info', type=str, help="Informations input")
parser.add_argument('-r','--res', type=str, nargs="+", help="Resid list to apply info. (format: CHAIN.RESID)")
parser.add_argument('-f','--resfile', type=str, help="Resid list file to apply info.")

if __name__ == '__main__':
	args = parser.parse_args(sys.argv[1:])
	addInfo(args)