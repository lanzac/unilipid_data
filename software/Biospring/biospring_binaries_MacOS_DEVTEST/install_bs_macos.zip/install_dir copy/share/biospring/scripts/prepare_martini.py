#!/usr/bin/env python3

from dataclasses import dataclass, field
from typing import List
import math
import numpy as np
import pandas as pd
import os

# https://stackoverflow.com/questions/1432924/python-change-the-scripts-working-directory-to-the-scripts-own-directory
# "This takes the filename of your script, converts it to an absolute path, then extracts the directory of that path, then changes into that directory."
abspath = os.path.abspath(__file__)
dname = os.path.dirname(abspath)
os.chdir(dname)

# https://static-content.springer.com/esm/art%3A10.1038%2Fs41592-021-01098-3/MediaObjects/41592_2021_1098_MOESM1_ESM.pdf
# Supplementary Table 17, 18 and 18 ; HD -> W
# For oil/water transfer free energies, six nonpolar organic phases
# were considered: hexadecane (HD), octanol (OCO), chloroform (CLF), ether (ETH),
# benzene (BENZ) and cyclohexane (CHEX).
colnames = ["Beads","HD->W","OCO->W","CLF->W","ETH->W","BENZ->W","CHEX->W"]
regular_transfer_energies = pd.read_csv("../data/martini/regular_oil_water_free_energies.csv", names=colnames, index_col=0, sep="\t", comment="#")
regular_transfer_energies["average"] = regular_transfer_energies.mean(numeric_only=True, axis=1)

small_transfer_energies = pd.read_csv("../data/martini/small_oil_water_free_energies.csv", names=colnames, index_col=0, sep="\t", comment="#")
small_transfer_energies["average"] = small_transfer_energies.mean(numeric_only=True, axis=1)

tiny_transfer_energies = pd.read_csv("../data/martini/tiny_oil_water_free_energies.csv", names=colnames, index_col=0, sep="\t", comment="#")
tiny_transfer_energies["average"] = tiny_transfer_energies.mean(numeric_only=True, axis=1)

nonpolar_organic_phase = "OCO->W"

residueName3To1 = {
        "ALA" : "A",
        "ARG" : "R",
        "ASN" : "N",
        "ASP" : "D",
        "ASX" : "B",
        "CYS" : "C",
        "GLU" : "E",
        "GLN" : "Q",
        "GLX" : "Z",
        "GLY" : "G",
        "HIS" : "H",
        "HSD" : "H",
        "HSE" : "H",
        "HID" : "H",
        "HSP" : "X",
        "ILE" : "I",
        "LEU" : "L",
        "LYS" : "K",
        "MET" : "M",
        "PHE" : "F",
        "PRO" : "P",
        "SER" : "S",
        "THR" : "T",
        "TRP" : "W",
        "TYR" : "Y",
        "VAL" : "V"
    }

REGULAR_BEADS_MASS = 72 # Da
REGULAR_BEADS_RADIUS = 4.7 # Å
SMALL_BEADS_MASS = 54 # Da
SMALL_BEADS_RADIUS = 4.1 # Å
TINY_BEADS_MASS = 36 # Da
TINY_BEADS_RADIUS = 3.4 # Å

@dataclass
class Bead:
    name : str = ""
    type : str = ""
    atoms: list[str] = field(default_factory=list)
    radius: float = 0.0
    charge: float = 0.0
    transfer_energy = 0.0
    mass = 0.0

    def get_radius(self) -> float:
        return self.radius
    
    def set_radius_and_mass(self):
        if (self.radius == 0.0):
            size_prefix = self.name[0]
            if   (size_prefix == 'R'): 
                self.radius = REGULAR_BEADS_RADIUS
                self.mass = REGULAR_BEADS_MASS
            elif (size_prefix == 'S'):
                self.radius = SMALL_BEADS_RADIUS
                self.mass = SMALL_BEADS_MASS
            elif (size_prefix == 'T'):
                self.radius = TINY_BEADS_RADIUS
                self.mass = TINY_BEADS_MASS
            else:
                self.radius = REGULAR_BEADS_RADIUS
                self.mass = REGULAR_BEADS_MASS
    
    def get_transfer_energy(self) -> float:
        #if (self.size == 0.0):
        return self.transfer_energy
        

def is_empty(string):
    return not string.strip()

def prep():

    amino_acids = ["ALA","ARG","ASN","ASP","CYS","GLN","GLU","GLY","HIS","ILE","LEU","LYS","MET","PHE","PRO","SER","THR","TRP","TYR","VAL"]
    amino_acids_beads_info = {aa: {} for aa in amino_acids}

    mapping_dir = "../data/martini/martini_v3.0.0_proteins/mappings/martini3001/"
    forcefield_dir = "../data/martini/martini_v3.0.0_proteins/force_fields/martini3001/"

    bonds = []

    for aa in amino_acids:
        
        aa_file_name = mapping_dir + aa.lower() + ".charmm36.map"
        aa_file = open(aa_file_name, "r")

        #aa_file = open(mapping_dir + "arg" + ".charmm36.map", "r")
        while aa_file:
            line = aa_file.readline()
            if line == "": break


            if ("[ atoms ]" in line):
                while True:
                    line = aa_file.readline()
                    if (is_empty(line)): break
                    n, atom, bead_name = line.replace("!", "").split()[:3]
                    if (bead_name not in amino_acids_beads_info[aa]):
                        new_bead = Bead(name=bead_name)
                        new_bead.set_radius_and_mass()
                        amino_acids_beads_info[aa][bead_name] = new_bead

                    amino_acids_beads_info[aa][bead_name].atoms.append(atom)

        aa_file.close()
    
    write_grp = open("../data/reducerules/martini.grp", "w")
    for aa, beads_dict in amino_acids_beads_info.items():
        for bead in beads_dict.values():
            res_name_1 = residueName3To1[aa]
            #particle_name = res_name_1 + "BB_" if (bead.name == "BB") else res_name_1 + bead.name
            particle_name = res_name_1 + bead.name
            atoms = bead.atoms
            write_grp.write("{} {} {}\n".format(particle_name, aa, ' '.join(atoms)))
    write_grp.close()

    ff_header = "#type	charge(e)	radius(A)	epsilon(kJ.mol-1)	mass(Da)	transferIMP(kJ.mol-1.A-2"

    ff_file = open(forcefield_dir + "aminoacids.ff", "r")
    while ff_file:
        line = ff_file.readline()
        if line == "": break
        if ("Links" in line): break

        # New amino acid
        if ("moleculetype" in line):
            ff_file.readline()
            aa = ff_file.readline().split()[0]
            # Check aa
            if (aa not in amino_acids):
                while True:
                    line = ff_file.readline()
                    if (line.startswith(";;;")): break #new aa
        
        # Read its atoms
        if  ("atoms" in line):
            line = ff_file.readline()
            if (not line.startswith(";id")): continue
            while True:
                line = ff_file.readline()
                if (is_empty(line)): break
                id, type, resnr, residu, bead_name, cgnr, charge = line.split()[:7]
                amino_acids_beads_info[residu][bead_name].type = "RP2" if "prot_default_bb_type" in type else type
                # Assign transfer energy ccording to bead size and bead type
                type = amino_acids_beads_info[residu][bead_name].type
                radius = amino_acids_beads_info[residu][bead_name].radius
                bead_surface = (4 * 3.1415926535898 * math.pow(radius, 2))
                
                if type[0] == "R":
                    amino_acids_beads_info[residu][bead_name].transfer_energy = -regular_transfer_energies.loc[type[1:3], nonpolar_organic_phase] / bead_surface
                if type[0] == "S":
                    amino_acids_beads_info[residu][bead_name].transfer_energy = -small_transfer_energies.loc[type[1:3], nonpolar_organic_phase] / bead_surface
                if type[0] == "T":
                    amino_acids_beads_info[residu][bead_name].transfer_energy = -tiny_transfer_energies.loc[type[1:3], nonpolar_organic_phase] / bead_surface

                amino_acids_beads_info[residu][bead_name].charge = float(charge)
        
        # Read beads bonds
        if ("bonds" in line):
            ff_file.readline()
            while True:
                line = ff_file.readline()
                if line.startswith(("#", ";")): continue

                if (is_empty(line)): break
                b1_name, b2_name, funct, length = line.split()[:4]
                rcode = residueName3To1[residu]

                bead1_name = rcode + b1_name
                bead2_name = rcode + b2_name

                bonds.append((rcode+b1_name, rcode+b2_name, float(length)*10))



    ff_file.close()

    write_ff = open("../data/forcefield/martini.ff", "w")
    write_ff.write(ff_header + "\n")
    for aa, beads_dict in amino_acids_beads_info.items():
        for bead in beads_dict.values():
            res_name_1 = residueName3To1[aa]
            #particle_name = res_name_1 + "BB_" if (bead.name == "BB") else res_name_1 + bead.name
            particle_name = res_name_1 + bead.name
            charge = amino_acids_beads_info[aa][bead.name].charge
            radius = amino_acids_beads_info[aa][bead.name].radius
            epsilon = 0.0 # TO DO 
            mass = amino_acids_beads_info[aa][bead.name].mass
            transfer_imp = amino_acids_beads_info[residu][bead.name].transfer_energy
            write_ff.write("{}\t{:.2f}\t{}\t{:.3f}\t{:.4f}\t{:.4f}\n".format(particle_name, charge, radius, epsilon, mass, transfer_imp))
    
    write_ff.write("\n#bonds\n#particle1  particle2   bondLength(A)\n")
    for p1, p2, l in bonds:
        write_ff.write("{}\t{}\t{:.2f}\n".format(p1, p2, l))

    write_ff.close()


if __name__ == '__main__':
    prep()