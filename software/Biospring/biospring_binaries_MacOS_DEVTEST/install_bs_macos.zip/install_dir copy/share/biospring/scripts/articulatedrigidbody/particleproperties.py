class ParticleProperties:
	def __init__(self, charge,radius, epsilon, mass,imp, hydro):
		self.charge=charge
		self.radius=radius
		self.epsilon=epsilon
		self.mass=mass
		self.imp=imp
		self.hydro=hydro
